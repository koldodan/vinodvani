---
layout: post
title: How does a devotee see the material world?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "An exalted devotee sees the material world as the Lord's mercy. Mercy, compassion, is woshiapble. It is not possible to surpass the Lord's compassion. If one sees this material world, which is meant for Lord's enjoyment, or the personification of the Lord's mercy in the spirit of enjoyment, one will certainly be punished."
---

An exalted devotee sees the material world as the Lord's mercy. Mercy, compassion, is woshiapble. It is not possible to surpass the Lord's compassion. If one sees this material world, which is meant for Lord's enjoyment, or the personification of the Lord's mercy in the spirit of enjoyment, one will certainly be punished.





















