---
layout: post
title: What is the difference between transcendental subject matter (adhoksaja) and spiritual subject matter (aprakrta)?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "We can realize the Supreme Lord only by devotional service. The Supreme Lord, who is transcendental, cannot be known by any other means. We achieve devotion simply by the mercy of the Supreme Lord and His devotees. We cannot understand the science of the Absolute Truth without the Lords mercy"
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

We can realize the Supreme Lord only by devotional service. The Supreme Lord, who is transcendental, cannot be known by any other means. We achieve devotion simply by the mercy of the Supreme Lord and His devotees. We cannot understand the science of the Absolute Truth without the Lord's mercy. _Chaitanya -caritamrita_ states, "if one receives but a tiny bit of the Lord's favor by dint of devotional service, he can understand the nature of the Supreme Persoality of Godhead." (Madhya 6.83)

There is no such thing as devotional service if the Personality of Godhead is ignored, because the Personaity of Godhead is the indispensable factor in devotional service.

We understand from the following Bhagwatam verse, beginning, "anartha upasamam saksad bhakti-yogam adhoksaje," that all _anarthas_ are destroyed when we engage in the Supreme Lord's service. That is why Adhoksaja has four arms: He destroys all _java's anarthas_ with His weappons. In the _adhoksaja_ conception, awe and reverence is prominent.

From the external viewpoint, the spiritual objet appears mundane, but it is not. In the conception of _aprakrta_ or spiritual object, there is no feeling of awe and reverence; the devotee feels only intimacy. There are no _anarthas_ in the conception of _aprakrta_. After our _anarthas_ are completely vanquished, the _aprakrta_ conception manifests. That _aprakrta_ or spiritual object is the two-armed form of Krsna playing a flute. He is served with love and devotion.

According to the understanding of _para, vyuha, vaibhava, antaryami, and archa_, the _para_ cannot be anyone other than Krsna. The word _aprakrta_ is applicable only to the Absolute Truth Krsna. The word _adhoksaja_ is applicable to _vyuha_ and _vaibhava_. The word _aparoksa_, indirect, is applicable to _antaryami_. Words like _paroksa_, direct, and _pratyaksa_, face-to-face, are applicable to _archa_.
