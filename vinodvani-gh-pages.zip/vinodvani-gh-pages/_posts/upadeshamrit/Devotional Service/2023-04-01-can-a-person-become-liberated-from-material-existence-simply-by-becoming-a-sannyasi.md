---
layout: post
title: Can a person become liberated from material existence simply by becoming a sannyasi?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Dressing like a sannyasi and becoming a real sannyasi are not the same thing. We have to take sannyasa from material enjoyment and the desire for liberation. One who has made Krsna's devotional service the essence of life by renouncing the desire for religiosity, economic development, sense gratification, and liberation is the real *sannyasi*."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Dressing like a _sannyasi_ and becoming a real _sannyasi_ are not the same thing. We have to take _sannyasa_ from material enjoyment and the desire for liberation. One who has made Krsna's devotional service the essence of life by renouncing the desire for religiosity, economic development, sense gratification, and liberation is the real _sannyasi_.

To become a real _sannyasi_ means to follow in the footsteps of the _mahajanas_ and to become attached to the transcendental Lord. In addition, dressing like a _sannyasi_ is nothing but imitation, pretense. Sri Mahaprabhu states: The real purpose of accepting _sannyasa_ is to dedicate oneself to the service of Mukunda. By serving Mukunda, one can actually be liberated from the bondage of material existence. (_Caitanya-caritamrita madhya 3.8_).

If after accepting _sannyasa_ one lovingly serves Krsna with body, mind, speech, wealth, knowledge, intelligence and his possessions, he can both become liberated from material existence and become a _bhakta_. It is impossible to attain any benefit without rendering the Supreme Lord service. Whether one lives at home or in Matha, one must engage in the lord's service as his life and soul. Then only can he please the Lord. He must give up miserliness and the propensity to cheat. If he can make the Lord's service the goal of life, he can attain the Lord's mercy in this lifetime.
