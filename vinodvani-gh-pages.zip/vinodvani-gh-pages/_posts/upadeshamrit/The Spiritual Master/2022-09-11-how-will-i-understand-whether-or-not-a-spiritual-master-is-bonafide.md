---
layout: post
title: How will I understand whether or not a spiritual master is bonafide?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'The spiritual master we choose, or a person who, according to our consideration is qualified to be guru, may not be bonafide. Only a person sent to us personally by Krsna will manifest before us as the spiritual master.'
---

The spiritual master we choose, or a person who, according to our consideration is qualified to be guru, may not be bonafide. Only a person sent to us personally by Krsna will manifest before us as the spiritual master.
