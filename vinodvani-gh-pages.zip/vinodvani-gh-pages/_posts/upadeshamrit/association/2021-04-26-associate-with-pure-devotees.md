---
layout: post
title: Is it extremely necessary to associate with pure devotees?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

Neophytes or kanişthā-adhikārīs cannot actually understand the importance of Deity worship. Their mundane conceptions regarding Deity worship do not completely go away. Neither are they aware of the supremacy and transcendental position of devotees. This is why saintly persons recommend that kaniştha-adhikārīs associate with əınd devotees. Without the association of pure devotees, human beings cannot attain benefit and can never properly worship the Deity.
