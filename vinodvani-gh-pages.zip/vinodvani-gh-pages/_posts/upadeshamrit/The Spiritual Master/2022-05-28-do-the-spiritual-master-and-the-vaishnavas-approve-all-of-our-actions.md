---
layout: post
title: Do the spiritual master and the vaishnvas approve all of our actions?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "As a good doctor does not prescribe cures according to the patient's desire, a bonafide spiritual master does not falsely encourage or flatter conditioned souls. I have no qualification to approve the actions of those who display or will display devotion to their fathers and mothers in order to achieve worldly happiness and peace. Our hearts are not righteous like theirs. We follow Vedic injunctions."
---

As a good doctor does not prescribe cures according to the patient's desire, a bonafide spiritual master does not falsely encourage or flatter conditioned souls. I have no qualification to approve the actions of those who display or will display devotion to their fathers and mothers in order to achieve worldly happiness and peace. Our hearts are not righteous like theirs. We follow Vedic injunctions. Our aim and ideal is simply to practice devotional service. Therefore, we are unable to pay attention to anything else. Neither can we take anyone else's advice while becoming indifferent to the service of guru and the Vaishnavas. We have no time to serve others while indulging in mental speculation, renouncing the Lord's service, which is our constitutional duty.
