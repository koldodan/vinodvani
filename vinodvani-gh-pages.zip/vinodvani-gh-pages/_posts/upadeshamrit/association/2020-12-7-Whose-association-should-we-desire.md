---
layout: post
title:  Whose association should we desire?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
description: The thoughts of karmis, gyanis, and yogis are born from their aversion towards the Lord. We should reject their association and associate only with Vaishnavas.
tags: association
---



He who says, "Worship the Supreme Lord," is certainly a spiritual master. Only devotees are honest and saintly; others are not. The thoughts of karmis, gyanis, and yogis are born from their aversion towards the Lord. We should reject their association and associate only with Vaishnavas. Only then will we find benefit.
