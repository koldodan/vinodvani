---
layout: post
title: Who is a devotee?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "One who sacrifies his happiness for Krsna's happiness and who remains always engaged in Krsna's service by remouncing his own enjoyment for Krsna's pleasure is a devotee. He certainly attains auspiciousness. Devotional service is the propensity to give Krsna pleasure. The endeavor to make oneself happy is non devotional service and is the source of misery."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

One who sacrifies his happiness for Krsna's happiness and who remains always engaged in Krsna's service by remouncing his own enjoyment for Krsna's pleasure is a devotee. He certainly attains auspiciousness. Devotional service is the propensity to give Krsna pleasure. The endeavor to make oneself happy is non devotional service and is the source of misery. A non devotee says, "I will become Krsna and intimately enjoy the association of woman." If one rejects such a mentality and becomes inspired by a Vaishnav's ideal example, he is guaranteed good fortune. If he does not keep himself engaged in Krsna's service, he will certainly become a material enjoyer or a dry renunciant rather than a vaishnav.





















