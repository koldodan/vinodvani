---
layout: post
title: Do we attain everything by taking shelter at the feet of a bonafide spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: First one should take shelter of a bonafide spiritual master, then he should take initiation and transcendental knowledge from him, he should serve his spiritual master with faith and devotion, and follow in the footsteps of a saintly person.
---

By taking shelter of the spiritual master's lotus feet, we can attain everything including Krsna's holy name and the mantras in relation to Krsna. But unless we have a strong service attitude toward our spiritual master's lotus feet, we canot realize these transcendental topics. Unless we take shelter of our spiritual master with firm faith and devotion and proceed on the devotional path under his order, we cannot attain real auspiciousness. The materialists are naturally fond of dry arguments. No one can understand devotional service by following the path of dry argumentation. Unless we take shelter of a Vaishnava spiritual master and execute devotional service under his guidance, we cannot properly utilize our own good intelligence. Therefore, the *sastra* says "First one should take shelter of a bonafide spiritual master, then he should take initiation and transcendental knowledge from him, he should serve his spiritual master with faith and devotion, and follow in the footsteps of a saintly person. (BRS 1.2.74)"















