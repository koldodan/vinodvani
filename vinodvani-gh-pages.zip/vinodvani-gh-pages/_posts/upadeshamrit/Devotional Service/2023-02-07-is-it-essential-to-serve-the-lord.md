---
layout: post
title: Is it essential to serve the Lord?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Our duty is to serve guru and Krsna, and we will continue to do so. Let Krsna do whatever He pleases. We must accept His arrangements without reservations. The daughter of Vrshabhanu does not give up Krsna's service because She is afraid of being criticized."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Our duty is to serve guru and Krsna, and we will continue to do so. Let Krsna do whatever He pleases. We must accept His arrangements without reservations. The daughter of Vrshabhanu does not give up Krsna's service because She is afraid of being criticized. 
