---
layout: post
title: Should we have immense faith in God?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'We are constantly inducing the Lords servants to enhance their faith in God. Their success, however, depends on their respective luck. If Krsna bestows His mercy, everyone will profit. We should always discuss topics about the Vaishnavas. Then the pride that we are enjoyers will not trouble us. Our mind can help us become bound by different kinds of material enjoyment, but when devotional service, the souls constitutional propensity, is awakened, the pure, uncontaminated spirit soul will always cultivate *hari-katha*.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

We are constantly inducing the Lord's servants to enhance their faith in God. Their success, however, depends on their respective luck. If Krsna bestows His mercy, everyone will profit. We should always discuss topics about the Vaishnavas. Then the pride that we are enjoyers will not trouble us. Our mind can help us become bound by different kinds of material enjoyment, but when devotional service, the soul's constitutional propensity, is awakened, the pure, uncontaminated spirit soul will always cultivate *hari-katha*.
