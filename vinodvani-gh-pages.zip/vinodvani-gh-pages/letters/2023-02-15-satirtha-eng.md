---
title:  Letter to Satirtha
layout: letters
permalink: letters/satirtha-eng_xyz_987
date: 2023-02-15
location: Ohio, USA 
date_of_posting: Feb 15th 2023
---

With repeated obeisances at the lotus feet of Śrī Vaiṣṇavas - <br>
Respected disciples,  grand- and great-grand disciples of Śrīla Guru Mahārāj, hoping you are doing well. 
<br>

At first, I pray to the first class Vaiṣṇavas who are descendents of Śrīla Guru Mahārāj in the relations of initiation or learning. Being at the stage of āpana-daśa, you have been serving Śrī Hari, observing complete peace in this world due to the mercy of Śrī Hari as per the verse “viśvaṁ pūrṇa sukhāyate.” Śrī Hari is supremely independent and so you are. Therefore, you may or may not respond to the prayer of this ignorant servant. However, as you know, our eternal Ācāryas, the crest jewels of the Vaiṣṇavas, have mercifully played the role of a madhyama Vaiṣṇava and preached Śrī Harinām and premā as well as vanquished all heretics. Would you also like to kindly take up on this role again, following Prabhupāda Śrīla Sarasvatī Ṭhakur’s pastimes of “hari-sādhana-kṛta-vādhana jana-śāsana-kalanaṁ”?
<br>

To the madhyama-adhikārī saints, - vaishnavas like you are rare in the world. Taking the conclusions of the scriptures to your heart, you land into the stage of sādhana. You see the grace of Śrī Hari on one side and the presence of Māyā on the other. Declaring a war against illusion, you are constantly engaged in sādhana. A blazing flame of serving temper shines in your heart. That fire is constantly reprimanding the wrongdoings against Guru Vaishnav. Will you kindly invigorate my lifeless heart with the heat of that fire? 
<br>

I have a few prayers in the form of questions. 
<br>

- During the time when Śrīla Guru Mahārāj̍a was the Ācārya (1976-1986), several of Srila Prabhupāda’s disciples performed service and preaching with and under the guidance of Śrīla Guru Mahārāja, residing at Śrī Caitanya Maṭh and various branches. Currently, in various occasions and assemblies, some are offensively describing that period to be "dark age". Isn’t it a heinous offense to speak as well as tolerate this slander?
- There is a warehouse-building in front of Ṣrīla Guru Mahārāj̍as bhajan kuṭir and samādhi temple. Doesn’t it obstruct services such as darṣan and kīrtan for the servitors and stand erect as a contempt-construction?
- Is Ṣrīla Guru Mahāraj̍a’s ārati held in the sequence, following the divine succession?
- Do you hear devotees glorifying Ṣrīla Guru Mahāraj̍a during the daily prayers and ārati?
- Have you not noticed the disconnection of disciplic succession while viewing the ālekhya of Guru-varga?
- Didnt you feel a natural heart-burn noticing the disrespects shown to Ṣrīla Guru Mahāraj̍as great contributions as the tenth generation-ācārya?

One could hear the tone of grief in the voices of many devotees observing these offenses. That’s natural! Śrīla Guru Mahārāja is praised by the greatest of the devotees as the very personification of the third verse - "tṛṇādapi sunīcena" and the One Who chants Śrī Harināma continually. How can we live unperturbed and stay indifferent while witnessing these offenses? Why shouldn’t we appeal to kindly refrain from the offenses involving denial of His Ācāryaśip? Isnt it true that a single drop of love, from the overflowing reservoir of premā of Śrīman Nityānanda Prabhu, is enough to change the mood of any heart? 
<br>

On the other hand, we are not from different parties. We belong to the same group, traveling the same path. The party-spirit and division are the acts of Kali. The Gauḍiya-Ācārya-Bhāskara Prabhupāda Śrīla Sarasvatī Ṭhākur declared a totalitarian war against Kali and Māyā, and saved us from impersonalism, atheism etc. We are only insignificant soldiers under His camp. Can we dress up as our own rivals?
<br>

Some are not optimistic about the results. They are more experienced. However, service is the duty of a servant. The benefactor is Śrī Hari Himself. I conclude the letter by quoting Śrīla Prabhupāda’s commentaries and letters in the appendix, asking for blessings. 
<br>

In service, a worthless servitor.
<br>

<p style="text-decoration: underline;">Appendix - Srila Prabhupāda’s Commentary-Excerpt:</p>

(1) Ṣrī Caitanya Bhāgavata - Madhya/20/144: <br>
&emsp; Many, under the pretense of syncretism, listen to the condemnation of Guru-Vaiṣṇava and still stay quiet. They fall into many generations of degradation. All their fortunes fade away. “nindāṃ bhāgavataḥ ṣṛṇvan tatparasya janasya vā. tato nāpaiti yaḥ so’pi yātyadhaḥ sukṛtāccyutaḥ. - (Refer to Bhakti-sandarbha 265)

<u> Appendix - Excerpts from Srila Prabhupāda’s Letters: </u>:

(2) Śrī Gauḍīya Maṭh, Calcutta - 11th May 1923: <br>
&emsp; …The emotion that arises when sense-perception is obstructed is anger. Devotees are always engaged in the service of Kṛṣṇa. If you try to prevent them from doing their service, the person who obstructs them can be called an offender. So the emotion of anger towards such offenders is only a variety of devotional activity. Those who equate such anger-like-devotion with general anger are hellish. A devotee has the strength to withstand the obstructions of sense gratification. So he is tolerant of his unsatisfied enjoyment. But being angry with the person obstructing Kṛṣṇa's service, they are actively engaged in service.

(3) Śrī Caitanya Maṭh, Śrīdhām-Māyāpur - 25th February, 1931: <br>
&emsp; …Therefore, seeing the disrespect towards the Vaiṣṇava Gurus arising in the minds of other offenders, if the editors of 'Gauḍīya' and 'Nadiya-Prakaṣa' remain silent, then their viśrambha-guru-seva is obstructed, I think you approve of this. Bhāgavata is the most tolerant. You are so; but you can never forgive that miscreant when you see the disrespect of your guru-varga. That is why our eternal gurudeva Ṭhakura Narottam has sung - "krodh bhakta-dveṣī-jane".

&emsp; The appointment of anger should be done over the offenders. Aversion to this action has produced heresy in the present prākṛta-sahajiyā community. You are wise, it is only my audacity to tell you this more.

&emsp; As a servitor of the Vaiṣṇavas, to bear the contempt of the Guru is not only a sin, — a debasing offense of the soul, — we know. Even if the whole world becomes our enemy for this, we will be ready to bear it.
