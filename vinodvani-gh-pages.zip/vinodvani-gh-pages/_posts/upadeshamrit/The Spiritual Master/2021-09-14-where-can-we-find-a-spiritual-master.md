---
layout: post
title: Where can we find a spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
---

Only the person Lord Krsna send us as spiritual master will manifest before us as our guru. By the Lord's mercy we attain a spiritual master, and by the spiritual master's mercy we attain Krsna. We are given a spiritual master according to our fortune. Different people have different mentalities, and the omniscent Lord sends each an appropriate spiritual master. There are those who desire the lord's nonduplicitous mercy and who completely depend on Him for their success. These souls please the Lord with their simple sincerity. To bestow His mercy upon them, he appears before them personally. To those who want something else from the Lord, who are not actually aspring for His complete mercy, the Lord sends through His illusory energy a spiritual master appropriate to their mentality. A sincere person never faces difficulty but quicky finds a bonafide guru.

