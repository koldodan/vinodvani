---
layout: post
title: What is Universal religion?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "People in this world currently regard activities such as following religious princiles or serving our fellow citizens as the topmost religion, but they are nothing but attempts at sense gratification by the atheistic community through the artificial processes of Karma, jyana, and yoga."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

People in this world currently regard activities such as following religious princiles or serving our fellow citizens as the topmost religion, but they are nothing but attempts at sense gratification by the atheistic community through the artificial processes of Karma, jyana, and yoga. Lord Krsna says in the Bhagavad-gita that we should giove up all varieties of religion and take complete shelter of Him, but by creating concocted religious systems in the name of synthesizing all religions, even as they transgress the Supreme Lord's instructions, the atheists are themselves cheated, just as they cheat others. Even though the poeple accept such cococted religious systems as truth, they distance themselves from actual truth. The endeavors of godless people, proud of their material knowledge, can never be accepted as supreme religious principles as _sanatana-dharma_. The only supreme religion for all humanity is unmotivated and uninterrupted devotional service to the transcendental Lord, Hari. _Sanatan-dharma_ is the eternal occupational duty of the spirit soul and gives benefit to all.

The Padma Purana says:

<p style="text-align:center"> <b> ārādhanānām sarveṣām, vişnor ārādhanam param </b></p>
<p style="text-align:center"> <b> tasmāt parataram devi, tadīyānām samarcanam </b></p>

"Of all types of worship, worship of Lord Vishnu is best, and better than the worship of Lord Vishnu is the worship of His devotee, the Vaishnava."

Therefore, better than worship of Krsna is the worship of the daughter of Vṛṣabhānu, of Nanda and Yaśodā, of Śrīdāmā and Sudāmā, and of Raktaka and Patraka.
