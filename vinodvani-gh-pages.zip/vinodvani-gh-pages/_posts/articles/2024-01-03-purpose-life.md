---
layout: letters
title: The Purpose of Life
description: The Purpose of Life
categories: articles
tags: articles
image:
  path: /img/Samadhi_Mandir.jpg
  height: 100
  width: 100
  alt: শ্রীগৌড়ীয় গোষ্ঠীপতি শ্রীশ্রীগৌরসরস্বতী প্রভুপাদ 
---

<!-- <p style="text-align:center"> Śrī Śrī Guru Gaurāṅgau Jayataḥ </p>  -->

<p style="text-align:center"> <b>  The Purpose of Life </b> </p> 

"ভোগী ও ত্যাগী উভয়েই বদ্ধ​।  ভক্ত নিত্য কৃষ্ণসেবাপর​।" - প্রভুপাদ শ্রীল ভক্তিসিদ্ধান্ত সরস্বতী গোস্বামী ঠাকুর 
<br> <br>

<p style="text-align:center">
<img src="/img/Srila_Prabhupada_Cm.jpg" 
     width="175" 
     height="245"
     alt="শ্রীগৌড়ীয় গোষ্ঠীপতি শ্রীশ্রীগৌরসরস্বতী " />
<br>
<b> শ্রীগৌড়ীয় গোষ্ঠীপতি শ্রীশ্রীগৌরসরস্বতী প্রভুপাদ </b>
</p>
<br> <br>

The purpose of life is not bhog or tyag but the purpose of life is Harbhajan and Harikatha for the pleasure of the Lord.
<br> <br>
 
In an assembly of devotees someone said that at the time of death we will come to know how much tyag we have done in life. Rupaanuga do not subscribe to this thought since as per Shrimad Bhagwat Gita the soul will go to the destination that it remembers at the time of death. If we remember Lord Shri Krishna, then we will go to his abode. Remembrance of the Lord at the time of death is only possible by Harbhajan or Harikatha. So at the time of death we will come to know how much Hari Bhajan we have done, not tyag. So, instead of tyag our focus should be engagement of our senses in the service of the Lord . Some people eat only fruits or drink only water, but this will not lead anywhere. There are so many birds who just eat fruits and so many other jivas who just live on water. Do these birds and jivas get Bhagwadprapti? No, that will simply increase our ego that I am a tyagi.
<br> <br>

Some people do mauna vrata. There are so many people who can not speak. Do they achieve God? The real mauna vrat is when we speak only Harinam and Harikatha. God has given us this tongue to glorify the Lord and sing Hari Katha. By keeping maun we are just increasing our ego. The real maun vrata will be to glorify the Lord and sing Hari Katha among the devotees.
<br> <br>
