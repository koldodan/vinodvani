---
layout: post
title: What is the function of the caitya-guru (SuperSoul) and the other forms of Guru?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "The Supreme Lord regulates the living entity's good and bad propensities by residing in their hearts as the Supersoul. The Supersoul or internal spiritual master directs all living entities. The Supersoul also guides us to a spiritual master. Aside from this, the spiritual master's servants act as instructing spiritual masters."
---

The Supreme Lord regulates the living entity's good and bad propensities by residing in their hearts as the Supersoul. The Supersoul or internal spiritual master directs all living entities. The Supersoul also guides us to a spiritual master. Aside from this, the spiritual master's servants act as instructing spiritual masters.

​ Persons who glorify the _sastras_, who explain _sastras_ to others, and who act according to sastric injunctions regulate the restless, _anartha_ filled mind of ignorant people. Such instructing spiritual masters help people before they receive initiation from a spiritual master.

​ Without the mercy of the internal spiritual master (_caitya-guru_), no one can become qualified to serve the lotus feet of the initiating and instructing spiritual masters. Until we accumulate piety in the form of Krsna's mercy, we cannot achieve the true mercy of the _caitya-guru_. As long as our hearts are filled with the desire for religiosity, economic development, sense gratification, and liberation, we cannot aspire for devotional service. If due to good fortune we desire to take shelter at the Lord's lotus feet, then the internal spiritual master will mercifully guide us to initiating and instructing gurus.

​ The devotee spiritual master is attained by the _caitya-guru_'s mercy. The _caitya-guru_ bestows mercy in two ways, and it is because of these two forms of mercy that some people become materialists and others become devotees. Materialists are people who have accepted sense gratification as their ultimate goal. Instead of searching for devotional service, which is the ultimate goal of life, such people seek temporary happiness. This is the _caitya-guru_'s tricky mercy. Only a cheater is fit to receive such tricky mercy. Pious, sincere devotees, however, become glorious by receiving the _caitya-guru_'s true mercy. If someone who despite becoming the Supreme Lord's servant wants something other than his Lord's service, what can he be but a cheater?

​ As instructing spiritual master teaches a surrendered disciple to accept an initiating spiritual master. Therefore, even though there may be many instructing spiritual masters, there is no difference in opinion between such gurus and the initiating spiritual master, who awards the disciple transcendental knowledge. Rather, an instructing spiritual master is the real friend of the initiating spiritual master.

​ A living entity's awareness of his constitutional position is revived when he receives transcendental knowledge. At that time those who give instructions regarding the process of Hari's devotional service are called instructing spiritual masters. The initiaiting spiritual master is situated between the commander-in-cheif and the ordinary soldiers who are in the form of instructing spiritual masters.

​ Only a person who is favored by the Lord in the form of the _caitya-guru_ receives the good fortune to understand the devotee of the Lord as his bonafide spiritual master. Only by the Lord's mercy can a living entity see the beauty of a bonafide spiritual master's toenails and thus make his life successful.
