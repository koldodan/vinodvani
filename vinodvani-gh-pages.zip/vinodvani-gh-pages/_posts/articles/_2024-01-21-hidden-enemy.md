---
layout: letters
title: প্রচ্ছন্ন শত্রু
description: প্রচ্ছন্ন শত্রু
categories: articles
tags: articles
image:
  path: /img/tbt.png
  height: 100
  width: 100
  alt: tbd 
---

<!-- <p style="text-align:center"> শ্রীশ্রীগুরু-গৌরাঙ্গৌ জয়তঃ </p>  -->

<p style="text-align:center"> <b>  প্রচ্ছন্ন শত্রু </b> </p> 

<b>tbd </b> <br>
tbd
<br> <br>


<p style="text-align:center">
<img src="/img/Srila_Prabhupada_Cm.jpg" 
     width="175" 
     height="245"
     alt="শ্রীগৌড়ীয় গোষ্ঠীপতি শ্রীশ্রীগৌরসরস্বতী " />
<br>
<b> শ্রীগৌড়ীয় গোষ্ঠীপতি শ্রীশ্রীগৌরসরস্বতী প্রভুপাদ </b>
</p>
<br> <br>

