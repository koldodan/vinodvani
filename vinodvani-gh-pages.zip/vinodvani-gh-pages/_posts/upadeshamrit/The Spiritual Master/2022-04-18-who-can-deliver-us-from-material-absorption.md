---
layout: post
title: Who can deliver us from material absorption?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "One who cannot deliver his dependents from the path of repeated birtha nd death should never become a spiritual master, a father, a husband, a mother, or a worshipable demigod."
---

Only the spiritual master who is an intimate associate of Sri Gauranga is capable of delivering us from death in the form of matreial existence. Now let us consider who is a spiritual master and who is insignificant. One who constantly serves the Absolute Truth, the supreme worshipable object of all spiritual masters, is a bonafide spiritual master. I am not talking about the guru who teaches vina or bodybuilding. Such persons cannot protect us from death. *Srimad-bhagwatam 5.5.18* says: "one who cannot deliver his dependents from the path of repeated birtha nd death should never become a spiritual master, a father, a husband, a mother, or a worshipable demigod"

​	When we are illusioned, we fall into death's trap.When we have knowledge, we are delivered. The knowledge earned from this world issueless when we find ourselves paralyzed or dying. If we do not search after Absolute Truth, then we are dead matter. One who cannot deliver his dependents from death is simply cheating. One who induces us to become attracted to sense gratification is certainly a cheater. But we should serve a spiritual master who protects us from all these cheaters. We should serve him every year, every month, every day, at every moment.

