---
layout: post
title: What is the difference between my spiritual master and me?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "I am more insignificant than the most insignificant, and the spiritual master, who is always engaged in serving the Almighty is greater than the greatest. "
---

I am more insignificant than the most insignificant, and the spiritual master, who is always engaged in serving the Almighty is greater than the greatest. 













