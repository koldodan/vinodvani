---
layout: post
title: What is Karta-bhaja, self-worship?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: '*Karta-bhaja* is an unauthorized *sampradaya* or sect. The followers of this sect are not Vaishnavas. They imagine that the spiritual master is Krsna Himself - that is, that the guru is the supreme enjoyer. Therefore, they think there is no need to worship Krsna. This is atheism. While it is true that the spiritual master is non-different from Krsna, it is not true that he is the supreme enjoyer. He is servitor god, a topmost devotee, the personification of devotional service. He is most dear to Krsna. In order to teach us how to serve Him, Lord Krsna appears in this world in the form of various spiritual masters.'
---

_Karta-bhaja_ is an unauthorized _sampradaya_ or sect. The followers of this sect are not Vaishnavas. They imagine that the spiritual master is Krsna Himself - that is, that the guru is the supreme enjoyer. Therefore, they think there is no need to worship Krsna. This is atheism. While it is true that the spiritual master is non-different from Krsna, it is not true that he is the supreme enjoyer. He is servitor god, a topmost devotee, the personification of devotional service. He is most dear to Krsna. In order to teach us how to serve Him, Lord Krsna appears in this world in the form of various spiritual masters. The spiritual master is not the energetic, but the Lord's energy. He is expert in rendering service to the Lord. He personifies devotion. Since he is servitor god, has no tinge of material desie. This is why Vaishnavas who are attached to his lotus feet can serve Krsna under his guidance. They adopt the process of devotional service as their life and soul. They never consider their spiritual master Rasabihari, Gopinatha, or Radhanatha.
