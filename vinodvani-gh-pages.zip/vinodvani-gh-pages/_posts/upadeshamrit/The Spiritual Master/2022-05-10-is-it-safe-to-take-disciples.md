---
layout: post
title: Is it safe to take disciples?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "Give up envy and become compassionate toward all living entities. Convert the godless living entities into devotees of Krsna. Do not become a guru and become envious. Do not become a guru so you can drawn in the ocean of material enjoyment. Do not become a guru for the sake of formality. But if you can become a sincere servant of your spiritual master and Krsna and attain their mercy, then there is nothing to fear. Otherwise, your degradation is guaranteed."
---

Give up envy and become compassionate toward all living entities. Convert the godless living entities into devotees of Krsna. Do not become a guru and become envious. Do not become a guru so you can drawn in the ocean of material enjoyment. Do not become a guru for the sake of formality. But if you can become a sincere servant of your spiritual master and Krsna and attain their mercy, then there is nothing to fear. Otherwise, your degradation is guaranteed.













