---
layout: post
title: What is the living entity's ultimate goal?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'Material enjoyment or liberation cannot be the living entitys ultimate goal. The living entities are servants of the Supreme Lord, so their ultimate goal is devotional service. Liberation is the other side of material enjoyment. Both material enjoyment and liberation are witches, because both pull the living entities away from righteousness. This is why God-fearing, pious people never take shelter of witchlike material enjoyment or liberation. The devotees of the Lord are already liberated souls and therefore do not hanker for liberation. We should give up karma and jyana and take shelter of devotional service.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Material enjoyment or liberation cannot be the living entity's ultimate goal. The living entities are servants of the Supreme Lord, so their ultimate goal is devotional service. Liberation is the other side of material enjoyment. Both material enjoyment and liberation are witches, because both pull the living entities away from righteousness. This is why God-fearing, pious people never take shelter of witchlike material enjoyment or liberation. The devotees of the Lord are already liberated souls and therefore do not hanker for liberation. We should give up karma and jyana and take shelter of devotional service.
