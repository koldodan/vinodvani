---
layout: post
title: How we will receive a bonafide spiritual master ?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'The Supreme Lord is present in our heart as the internal spiritual master and outside our heart as a pure devotee. If we are sincere, the Lord will guide us to a pure devotee. We may approach Him and beg for such mercy,  but He is the sole in-charge for granting our wish. We cannot question Him if He refuses to grant it. Krsna is not the caretaker of our garden. Our duty is to wait patiently for His mercy.'
---

The Supreme Lord is present in our heart as the internal spiritual master and outside our heart as a pure devotee. If we are sincere, the Lord will guide us to a pure devotee. We may approach Him and beg for such mercy, but He is the sole in-charge for granting our wish. We cannot question Him if He refuses to grant it. Krsna is not the caretaker of our garden. Our duty is to wait patiently for His mercy. In the meantime, we should give up material desire and engage in His service. If we sincerely seek His mercy, He will certainly bestow it upon us. Simply by His mercy we will obtain a bonafide spiritual master. _Sri Chaitanya Charitamrita_ states, "Krsna is situated in everyone's heart as the _caitya-guru_, the spiritual master within. When He is kind to some fortunate conditioned soul, he personally gives him lessons so he can progress in devotional service, instructing the person as the Supersoul within and the spiritual master without."

CC Madhya 22.47
