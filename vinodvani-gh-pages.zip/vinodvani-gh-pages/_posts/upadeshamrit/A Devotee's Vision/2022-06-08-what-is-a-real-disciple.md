---
layout: post
title: What is a real disciple?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "One whose life and soul is his guru, whose ideal is his spiritual master, whose aim is to serve his spiritual master, and who is more partial to his spiritual master even though he has equal love and devotion for Krsna, is an actual disciple. Real disciples are not weak, they are strongly upheld by the spiritual master's mercy. Their strength and hope are the service and mercy of their spiritual master. Real disciples never transgress thier guru's order even when their life is at stake. Because disciples follow the guru's order as their life and soul, they are qualified to recieve their spiritual master's mercy."
---

One whose life and soul is his guru, whose ideal is his spiritual master, whose aim is to serve his spiritual master, and who is more partial to his spiritual master even though he has equal love and devotion for Krsna, is an actual disciple. Real disciples are not weak, they are strongly upheld by the spiritual master's mercy. Their strength and hope are the service and mercy of their spiritual master. Real disciples never transgress thier guru's order even when their life is at stake. Because disciples follow the guru's order as their life and soul, they are qualified to recieve their spiritual master's mercy.























