---
layout: post
title: Don't you have many disciples?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'I have not made any disciples. Everyone is my spiritual master. I learn something from everyone. My only prayer is that they may mercifully award me the opportunity to follow their non-duplicitous ideal of worshiping the Lord.'
---

I have not made any disciples. Everyone is my spiritual master. I learn something from everyone. My only prayer is that they may mercifully award me the opportunity to follow their non-duplicitous ideal of worshiping the Lord.
