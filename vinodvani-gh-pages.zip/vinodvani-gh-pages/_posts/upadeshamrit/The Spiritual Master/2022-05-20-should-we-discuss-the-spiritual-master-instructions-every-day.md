---
layout: post
title: Should we discuss the spiritual master's instructions everyday?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "Among the vaishnavas, the spiritual master is topmost. It is essential to listen eternally to the instructions of the spiritual master, who is dear to Krsna. If we do not discuss or hear our spiritual master's instructions everyday but engage in other activities, we will simply invite distress. We should not imitate the spiritual master or the Vaishnavas. Such initation constitutes bad association. Rather, we should follow in their footsteps. We should associate with those devotees in whose hearts the Lord resides. Devotees and non devotees, liberated souls and conditional souls, perfect souls and imprefect souls, these are not one and the same. Raw rice is not fit for our eating; it becomes fit only after it is cooked. Similarily, we should associate with perfected devotees. That is both most desirable and auspicious."
---

Among the vaishnavas, the spiritual master is topmost. It is essential to listen eternally to the instructions of the spiritual master, who is dear to Krsna. If we do not discuss or hear our spiritual master's instructions everyday but engage in other activities, we will simply invite distress. We should not imitate the spiritual master or the Vaishnavas. Such initation constitutes bad association. Rather, we should follow in their footsteps. We should associate with those devotees in whose hearts the Lord resides. Devotees and non devotees, liberated souls and conditional souls, perfect souls and imprefect souls, these are not one and the same. Raw rice is not fit for our eating; it becomes fit only after it is cooked. Similarily, we should associate with perfected devotees. That is both most desirable and auspicious.
