---
layout: post
title: Will whatever we do out of duty destroy nescience?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'Our sense of duty and gratitude are mental functions, not characteristics of the soul. Actions performed out of duty are based on the mind, intelligence and false ego, whereas devotional Service is an activity of the soul.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Our sense of duty and gratitude are mental functions, not characteristics of the soul. Actions performed out of duty are based on the mind, intelligence and false ego, whereas devotional Service is an activity of the soul. If we have not acted out of pure love, we cannot call our actions pure devotion.Only what we perform with love and devotion can be called pure devotion. Duty is but regulation. Devotional service is the soul's constitutional propensity, and to maintain a sense of duty is the mind's propensity. If we wish to find fortune, we must follow the soul's constitutional propensity.
