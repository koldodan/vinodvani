---
layout: letters
title: Oh! Bhagavatī Mātā 
description: Oh! Bhagavatī Mātā 
categories: articles
tags: articles
image:
  path: /img/Smt_Bhagavati_Mata.jpg
  height: 100
  width: 100
  alt: Śrīmatī Bhagavatī Mātā Jagajjananī
---

<!-- <p style="text-align:center"> শ্রীশ্রীগুরু-গৌরাঙ্গৌ জয়তঃ </p>  -->

<p style="text-align:center"> <b> হে মাতঃ - তোমার বিমলা প্রসাদ </b> </p> 

&emsp; জগজ্জননী শ্রীমতী ভগবতী মাতা

<img src="/img/Smt_Bhagavati_Mata.jpg" 
     width="200" 
     height="310"
     alt="জগজ্জননী শ্রীমতী ভগবতী মাতা" />

**Śrīmatī Bhagavatī Mātā, Jagajjananī**


