---
layout: post
title:  How should we live?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---



It is certainly essential to associate with the spiritual master and with vaishnavas who are fully surrendered to the spiritual master. Unless we associate with Vaishnavas, how will unqualified people like ourselves learn the proper code of conduct and come to serve guru? We always need ideal examples. If we don't associate with Vaishnavas who are fixed at the spiritual master's lotus feet, attached to chanting the holy name, and fixed in the Lord's service, we cannot ourselves become fixed at guru's feet. We cannot learn to consider the spiritual master our well-wisher. We cannot understand that the spiritual master is as good as God. We cannot develop the tendency to serve the spiritual master. If genuine devotees who are fixed at the guru's feet teach us neither how to serve the spiritual master nor how to behave when we are with him, then even after receiving a bona fide spiritual master we may lose him. We would be losing a coveted jewel if we were bereft of his service.