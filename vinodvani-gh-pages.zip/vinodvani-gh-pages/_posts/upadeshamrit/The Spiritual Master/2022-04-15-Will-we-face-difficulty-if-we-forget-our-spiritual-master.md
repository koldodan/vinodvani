---
layout: post
title: Will we face difficulty if we forget our spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "The moment I fall down from the service to my spiritual master, who is protecting me at every moment by keeping me at his lotus feet, I will become distracted from the Absolute Truth. As soon as I fall away from my spiritual master's shelter, I will be captured by innumerable material desires."
---

The moment I fall down from the service to my spiritual master, who is protecting me at every moment by keeping me at his lotus feet, I will become distracted from the Absolute Truth. As soon as I fall away from my spiritual master's shelter, I will be captured by innumerable material desires. When I run to bathe, I will become busy protecting myself from cold. I will spend my time running to perform activities other than my spiritual master's service. If I do not perform activities other than my spiritial master's lotus feet - the lotus feet of that spiritual master who has always protected me from the material concept of life - at the beginning of every year, every month, every day, every moment, I will certainly find myself in trouble. I will pretend to become the spiritual master myself and expect others to adore me. This is the material conecption of life. It is not that we should worship our spiritusl master for only a day; we should serve him at every moment.



​	





 

