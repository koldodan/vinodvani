---
layout: post
title: Should everyone be respected as a Spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "One should not disobey his spiritual master. We should not blaspheme the Vedic literature or disrespect the guru by considering many persons his equal. The only benefit the living entities can experience is to take complete shelter of the Supreme Personality of Godhead, Krsna."
---

One should not disobey his spiritual master. We should not blaspheme the Vedic literature or disrespect the guru by considering many persons his equal. The only benefit the living entities can experience is to take complete shelter of the Supreme Personality of Godhead, Krsna.

​	My Spiritual master is an ocean of mercy. A single drop of that mercy ocean can drawn me in an ocean of happiness. Out of great compassion, my spiritual master used to tell me, "Give up your high education, sanctity, high birth, and come to me. You do not need to go anywhere else. Whatever you need ---whatever house, palace, knowledge, self-control, or renunciation ---you will attain simply by coming to me. Do not run after these insignificant material objects. Do not consider them the goal of your life. Ordinary people consider such things important".













