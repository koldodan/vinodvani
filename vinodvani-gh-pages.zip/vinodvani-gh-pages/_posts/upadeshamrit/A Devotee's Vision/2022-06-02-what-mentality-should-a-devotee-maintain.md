---
layout: post
title: What mentality should a devotee maintain?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "The *Kena Upanisad* states that having received specific powers from the omnipotent Supreme Lord, the demigods perform their respective duties. When that power is withdrawn, the demigods lost their potency. Devotees who follow in Sri Rupa's footsteps rather than placing their faith in themselves attribute all glories to their source. We do everything for the pleasure of Sri Krsna Chaitanya, Sri Rupa, Sri Bhaktivinoda Thakura, and our spiritual master. As soon as we give up the path of devotional service, the path of subordination to Krsna, false ego and illusion swallow us."
---

The *Kena Upanisad* states that having received specific powers from the omnipotent Supreme Lord, the demigods perform their respective duties. When that power is withdrawn, the demigods lost their potency. Devotees who follow in Sri Rupa's footsteps rather than placing their faith in themselves attribute all glories to their source. We do everything for the pleasure of Sri Krsna Chaitanya, Sri Rupa, Sri Bhaktivinoda Thakura, and our spiritual master. As soon as we give up the path of devotional service, the path of subordination to Krsna, false ego and illusion swallow us.























