---
layout: post
title: Is the desire for frame an impediment on the devotional path?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'There is no point accumulating material fame. We should remember that material fame is like the hog stool. It is to be rejected. There are two paths in life, *sreyas* and *preyas*. The materialists follow *preyas* and desire wealth, women, and fame. Travelers on the devotional path follow *sreyas* and are therefore freed from material desire. That is why association with devotees is most beneficial.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

There is no point accumulating material fame. We should remember that material fame is like the hog stool. It is to be rejected. There are two paths in life, _sreyas_ and _preyas_. The materialists follow _preyas_ and desire wealth, women, and fame. Travelers on the devotional path follow _sreyas_ and are therefore freed from material desire. That is why association with devotees is most beneficial.
