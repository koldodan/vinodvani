---
layout: post
title: How can we achieve mental strength?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

We are weak and need to become mentally strong. Our mental condition will become stronger if we faithfully hear *hari-katha* from living devotees. It is not possbile to strengthen our mental state without associating with devotees.





