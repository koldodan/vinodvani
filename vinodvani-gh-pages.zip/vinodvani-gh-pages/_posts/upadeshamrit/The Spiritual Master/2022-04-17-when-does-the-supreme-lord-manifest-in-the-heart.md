---
layout: post
title: When does the Supreme Lord manifest in the heart?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "If, out of good fortune, we can feel the spirtual master's presence in our heart, if we can see the spiritual master traveling and walking in our heart, then the Supreme Lord will manifest in out heart too. There is no way to attain the Lord's service other than by serving and satisfying that personality who always inspires us to offer our devotion to the Lord"
---

If, out of good fortune, we can feel the spiritual master's presence in our heart, if we can see the spiritual master traveling and walking in our heart, then the Supreme Lord will manifest in our heart too. There is no way to attain the Lord's service other than by serving and satisfying that personality who always inspires us to offer our devotion to the Lord.





