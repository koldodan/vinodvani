---
layout: post
title: How can we destroy dissatisfaction?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'Fighting battles of speech, bodily comforts, and battles in the form of mental dissatisfaction will not allow us to serve Lord Hari. Therefore, become as tolerant as a tree and by the Lords will continue to live at Kurukshetra. By doing so, we will attain auspiciousness. We wait for that day when Sri Gaurahari will send us to some other place.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

If we are devoted to the Supreme Lord, we have no cause to feel dissatisfied. Because we are averse to the Lord's service, we are compelled to enjoy the fruits of our karma in this world. As a result of our karma, sometimes we enjoy happiness, sometimes we suffer miseries, and sometimes we become envious of others. If we realize that the Lord's service is our ultimate goal, then the miseries and desires for material happiness cannot disturb us. We should always engage our mind in the Supreme Lord's service. If we do so, no harm can come to us. If we become agitated and live in this world by displaying our dissatisaction before others, we will not remember topics about the Lord's service.

Fighting battles of speech, bodily comforts, and battles in the form of mental dissatisfaction will not allow us to serve Lord Hari. Therefore, become as tolerant as a tree and by the Lord's will continue to live at Kurukshetra. By doing so, we will attain auspiciousness. We wait for that day when Sri Gaurahari will send us to some other place.
