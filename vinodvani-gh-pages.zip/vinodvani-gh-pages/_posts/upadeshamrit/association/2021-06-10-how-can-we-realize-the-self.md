---
layout: post
title: How can we realize the self?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

I can realize myself and regain my spiritual form simply by the mercy of my spiritual master, who is an intimate devotee of Krsna. We must always associate with devotees, because simply by associating with them we can recieve information about our spiritual form, our constitutional position. Once we have received this information, we will no longer consider the material body the self and our sense desires will be destroyed. Constitutionally, we are the Supreme Lord's eternal servants. This conception will be awakened in us if we engage in the **Lord's service in the association of devotees**. Then we will not be tempted by material enjoyment, which is the propensity of a conditioned soul.



