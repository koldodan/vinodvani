---
layout: post
title: Does a devotee see Krsna everywhere?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "According to a Vaishanav's transcendental vision, the Lord is eternally present in water as well as on earth. He is present in each and every atom. The Lord is situated everywhere as the SuperSoul. But he does not come under the purview of those nondevotees who are attached to wealth, women and fame. Such people do not believe in the Vaishnav's conviction. But Lord Narsimhadeva, who proved His devotee's words true, proved that Supreme Lord is everywhere by appearing from a stone pillar. Sri Narsimhadeva destroys impediments on the path of *bhakti*."
---

According to a Vaishanav's transcendental vision, the Lord is eternally present in water as well as on earth. He is present in each and every atom. The Lord is situated everywhere as the SuperSoul. But he does not come under the purview of those nondevotees who are attached to wealth, women and fame. Such people do not believe in the Vaishnav's conviction. But Lord Narsimhadeva, who proved His devotee's words true, proved that Supreme Lord is everywhere by appearing from a stone pillar. Sri Narsimhadeva destroys impediments on the path of *bhakti*.

























