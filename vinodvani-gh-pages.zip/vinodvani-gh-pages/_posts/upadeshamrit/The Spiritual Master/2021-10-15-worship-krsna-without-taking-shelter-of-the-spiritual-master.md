---
layout: post
title: Isn't it possible to worship Krsna without taking shelter of the spiritual master's lotus feet?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "If we fail to subordinate ourselves to Her representative, the spiritual master, we will not be able to cultivate Krsna consciousness or even please Krsna."
---

We must cultivate Krsna consciousness under the guidance and order of Krsna's devotee. The daughter of Vrsabhanu is most favorable to Krsna. Another name for Sri Radha is **anukulyena** or favorable. The spitiual masters are the dearest companions of the daughter of Vrsnabhanu. We **Gaudiya Vaisnavas**  worship Sri Radha Krsna. Actually, Gaudiya Vaishnavas are more partial to Radha than Krsna. The spiritual master is nondifferent from Sri Radha. Cultivation of Krsna consciousness is done under Sri Radha's guidance and in subordination to Her. If we fail to subordinate ourselves to Her representative, the spiritual master, we will not be able to cultivate Krsna consciousness or even please Krsna. Rather, we will only dance wildly for our own happiness. By renouncing such adverse mentality, such pride, and by serving Krsna under our guru's order, we will be benefited. 

​	But unfortunately we have forgotten to satisfy Krsna and are busy satisfying our own senses. Alas! Instead of making Krsna the centre of our household we have made ourselves the centre and have become attached householders. If we are actually interested in our own benefit, we must take special care during our present life. Otherwise, we will be cheated and will lose an excellent opportunity.

 

