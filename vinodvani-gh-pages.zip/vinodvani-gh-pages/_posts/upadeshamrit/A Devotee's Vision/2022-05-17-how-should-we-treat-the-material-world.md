---
layout: post
title: How should we treat the material world?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "We should see this material world and everything in it as full of ingredients for the Lord's service. Everything in this world is meant for Krsna's service. The day when we can look at the world like this and become liberated from the material conception, we will be able to see the material world as tje spiritual world, Goloka. We should treat all women as Krsna's beloveds. They are to be enjoyed by Him."
---

We should see this material world and everything in it as full of ingredients for the Lord's service. Everything in this world is meant for Krsna's service. The day when we can look at the world like this and become liberated from the material conception, we will be able to see the material world as the spiritual world, Goloka. We should treat all women as Krsna's beloveds. They are to be enjoyed by Him. Do not look at them with an enjoying spirit. They are meant to be enjoyed by Krsna, never by the living entities. Treat your father and mother as Krsna's father and mother. Instead of considering your children your servants, treat them as friends of child Krsna. Then you will not see the material world everywhere but Goloka.



















