---
layout: post
title: Is the occupational duty of Kali-yuga devotional service?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "What to speak of Kali-yuga, devotional service is the occupational duty of all yugas, for all times, and for all people. Activities like karma, jyana, and yoga are only temporary duties."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

What to speak of Kali-yuga, devotional service is the occupational duty of all yugas, for all times, and for all people. Activities like karma, jyana, and yoga are only temporary duties. They are not the spontaneous duties of living entities. Only devotional service is the eternal occupational duty of liberated souls. The occupational duties of conditioned souls afflicted by _anarthas_ are called karma, jyana, yoga, tapa and vrata.
