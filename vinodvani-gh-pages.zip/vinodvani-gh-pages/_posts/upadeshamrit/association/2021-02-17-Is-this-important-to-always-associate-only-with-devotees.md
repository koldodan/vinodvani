---
layout: post
title:  "Is this important to always associate only with devotees?"
date:   2021-02-17 21:45:43 -0500
categories: "upadeshamrit"
author: "Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur"
permalink: /:categories/Is-this-important-to-always-associate-only-with-devotees
tags: association
---



We should always remain in Vaishnava association. We are so weak that we cannot survive without Vaishnava association. If we remove ourselves from their association, we will again develop the sinful mentality that we are masters. If we do not always follow the orders of guru and the Vaishnavas, we will find ourselves in great danger. As soon as we remove ourselves from their shelter, Maya will capture us. Then we will again wander through the universe as Maya's servants.
