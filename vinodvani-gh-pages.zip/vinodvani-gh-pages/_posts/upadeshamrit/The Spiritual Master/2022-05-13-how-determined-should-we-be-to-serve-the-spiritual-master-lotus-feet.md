---
layout: post
title: How dertermined we should be to serve the spiritual master's lotus feet?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'A real disciple accepts his spiritual master as servitor of God, most dear to Krsna. He never considers his spiritual master inferior to the Lord in any way. A sincere disciple serves and worships his spiritual master as if he were God. Those who do not follow this principle fall down from their position as disciples.'
---

A real disciple accepts his spiritual master as servitor of God, most dear to Krsna. He never considers his spiritual master inferior to the Lord in any way. A sincere disciple serves and worships his spiritual master as if he were God. Those who do not follow this principle fall down from their position as disciples. Until we see the spiritual master as a manifestation of and nondifferent from the Supreme Lord, we will not be able to chant the Lord's name purely. A genuine disciple must possess firm determination and faith in his spiritual master, thinking, "I will serve my spiritual master and Lord Gauranga with utmost simplicity. I will follow my spiritual master's instructions, which have come down from the Supreme Lord. I will never disobey my spiritual master's orders under the influence of anyone in this world. If following my spiritual master means, I must beccome proud or an animal or go to hell forever, I will never hesitate. I will not follow anyone other than my spiritual master. I will destroy the current of mundane thought by the strength of his instructions. If my spiritual master showers even a particle of pollen from his lotus feet upon the world, then millions of people will be delivered. there is no knowledge or proper code of conduct in the fourteen worlds that weighs more than a partcile of dust from the lotus feet of my spiritual master."
