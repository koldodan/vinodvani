---
layout: post
title: Is working for Krsna, devotional service?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'A devotee has no engagement other than to work for Krsna. Whatever the pure devotees so for the Lords pleasure is devotional service. A person is subject to enjoy the fruits of his work if he considers himself the doer. Therefore, there is a gulf of difference between Karma and *bhakti*.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

A devotee has no engagement other than to work for Krsna. Whatever the pure devotees so for the Lord's pleasure is devotional service. A person is subject to enjoy the fruits of his work if he considers himself the doer. Therefore, there is a gulf of difference between Karma and *bhakti*.
