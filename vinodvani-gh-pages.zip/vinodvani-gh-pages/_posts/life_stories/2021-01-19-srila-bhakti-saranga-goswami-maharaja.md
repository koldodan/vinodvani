---
layout: page
title:  Srila Bhakti Saranga Goswami Maharaja
categories: [life stories]
tags: life_stories
---

In 1919, Srila Maharaja was initiated by Prabhupada Srila Sarasvati Thakura and was named as Sri Aprakrita Bhakti Saranga Goswami Prabhu. At the age of 32 years, he resigned from his job and came to Srila Prabhupada and submitted himself, and offered all his earnings and savings.

…
Once Srila Goswami Maharaja was very sick with high fever and he slept mostly unconscious. In the morning he saw Sri Gurudeva Srila Prabhupada was putting wet-strip on his forehead and fanning to reduce fever. He learned that Sri Gurudeva has been sitting up and was taking care of him for two consecutive nights. Knowing this he became very uncomfortable and apologetic. Srila Maharaja paid obeisances and expressed his gratitude. Srila Prabhupada replied affectionately as "I have enormous hope that you will be performing wonderful services.  No one else in your place can do so. Sri Gaurhari has brought you in.  After losing you, I was feeling very helpless. Sri Gaur Sundar is very merciful, so He brought you back in."

…


The audience in London wanted to have darshan of transcendental form of Sri Krishna. This was obvious as the previous preachers had presented the formless conception of the Godhead. Srila Goswami Maharaja wanted five days' time and he was searching for a diety of Sri Krishna since he only had Gomati and Govardhan Shila with him. In the following nights he dreamed of his Sri Gurudeva and he also saw Sri Krishna form within the Shila. He anxiously prayed for Saccidanda Vigraha. On the third night he dreamed that a wonderful Vasudev diety is present under a palm tree in the Sington garden. After getting up early in the morning, he went to that garden and recovered and brought in the Four-handed Vishnu diety and started His worship. That was in August 1937. In the next assembly under the chairmanship of lord Jetland, Srila Maharaja had presented the diety to the entire audience as per his previous promise.
