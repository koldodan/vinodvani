---
layout: post
title: Is the spiritual master an ordinary man?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "The spiritual master is sheltered, and Lord Krsna is the shelter. The spiritual master is servitor God and Sri Krsna is the object of service, the personality of Godhead. The spiritual master is most dear to Lord Mukunda. In the vision of a self-realized disciple on the *raga* path, the spiritual master is Krsna's energy and a manifestation of Vrsabhanu's daughter."
---

The spiritual master is not a temporary, perishable lump of flesh and blood. *Srimad-Bhagwatam* states that the spiritual master is  Lord Himself. He is an incarnation of the lord. Of his own sweet will, the spiritual master mercifully descends from the spiritual world to this world. He is eternally present both in the Lord's manifest and in unmanifest pastinmes. He always acts as our guide and gives us proper guidance.

​	The spiriutal master is an extraordinary personality. He is eternal and full of knowledge and bliss. To consider him ordinary human being is to be possessed of a hellish mentality. To think like this is an offense against the Holy name. The spiritual master is self-realized; he knows th science of Krsna. He is dear to Sri Chaitanyadeva. He has appeared in this world to deliver fallen souls like us. He is not a *Karmi*, *gyani*, or *yogi* . He is an associate of the Lord in His pastimes. He is topmost devotee. As God is eternal, so is the spiritual master. The transcendental Cupid, Krsna, is God. The spiritual master is nondifferent from that same Krsna. He is manifestation of Krsna.

​	When we consider the spiritual master as nondifferent from God, we recognize that the spiritual amster is worshipable God. Although he is the worship able Supreme Lord, he is most dear to the Lord. The spiritual master manifest the pastimes of worshiper God. The spiritual master and Krsna are simultaneously one and differnet. The spiritual master is sheltered, and Lord Krsna is the shelter. The spiritual master is servitor God and Sri Krsna is the object of service, the personality of Godhead. The spiritual master is most dear to Lord Mukunda. In the vision of a self-realized disciple on the *raga* path, the spiritual master is Krsna's energy and a manifestation of Vrsabhanu's daughter. The spiritual master, who is dear to Krsna, is part of Krsna's internal energy; Lord Krsna is the supreme energenic. Krsna is the male or enjoyer, and the spiritual master is the female or beloved of Krsna.

 

