---
layout: post
title: How do we attain devotional service to Krsna?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "By attentively hearing _krsna-katha_ with a service attitude from sincere devotees of the Lord who have no business other than to constantly glorigy Him, we can attain devotional service to the Supreme Personality of Godhead, Krsna."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

By attentively hearing _krsna-katha_ with a service attitude from sincere devotees of the Lord who have no business other than to constantly glorigy Him, we can attain devotional service to the Supreme Personality of Godhead, Krsna.
