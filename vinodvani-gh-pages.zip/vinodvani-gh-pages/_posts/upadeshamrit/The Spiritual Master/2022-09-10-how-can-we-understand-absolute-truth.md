---
layout: post
title: How can we understand the Absolute Truth?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'The Absolte Truth is the Supreme Personality of Godhead. He is cause of all causes. The Absolute Truth is self-manifest. He is not dead matter. He is fully cognizant. He manifests before us out of His own sweet will. It is impopssible to know Him by mundane experience or the ascending path. The Absolute is not an object belonging to the third dimension. We can measure objects belonging to the third dimension. Anything that can be measured with our material senses belongs to the world of Maya.'
---

The Absolte Truth is the Supreme Personality of Godhead. He is cause of all causes. The Absolute Truth is self-manifest. He is not dead matter. He is fully cognizant. He manifests before us out of His own sweet will. It is impopssible to know Him by mundane experience or the ascending path. The Absolute is not an object belonging to the third dimension. We can measure objects belonging to the third dimension. Anything that can be measured with our material senses belongs to the world of Maya.

​ As we have to open our eyes if we wish to see the sun, we have to wait until our internal spiritual consciousness is revived before we can realize the Absolute. As we cannot see the sun at night even if we illuminate the sky with thousands of electric lights and as there is no need of artificial lighting once the sun rises in the morning so the Absolute Truth cannot be illuminated by sensually acquired knowledge. As long as we are materially conditioned, we cannot understand the Absolute Truth's identity. We must hear about Him from our spiritual master. Thus there is no way to know the Absolute Truth except to surrender at our spiritual master's lotus feet.
