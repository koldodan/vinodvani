---
layout: post
title: Is it most essential to serve the Spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "If the Vaishnavas, who are fixed at the spiritual master's lotus feet, do not instruct us how to approach, serve, and deal with our spiritual master, we may lose a coveted jewel."
---

It is extremely necessary to worship the spiritual master. Even if we want to become a successful *karmi*, *jyani* or *sense enjoyer*, we require a spiritual master's guidance. But the knowledge imparted by spiritual masters teaching such things produces insignificant results. A bonafide spiritual master, however, does not award temporary or insignificant results. A real spiritual master awards actual auspiciousness.

​	As soon as, we forget the compassion our spiritual master has shown us we invite material desires into our hearts. If the Vaishnavas, who are fixed at the spiritual master's lotus feet, do not instruct us how to approach, serve, and deal with our spiritual master, we may lose a coveted jewel.







