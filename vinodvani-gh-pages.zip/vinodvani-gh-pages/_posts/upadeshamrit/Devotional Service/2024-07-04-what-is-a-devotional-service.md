---
layout: post
title: What is a devotional service?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Devotional service means to please Krsna. When practicing devotional service, there is no question of desiring sense gratification. The devotees do not serve Krsna for any other purpose than to please Him."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

The path devoid of _krsna-katha_ is a a nondevotional path. Devotional service means cultivating Krsna consciousness. The word "cultivation" means to serve continuously. When a living entity in devotional service, he is called a devotee.

Devotional service means to please Krsna. When practicing devotional service, there is no question of desiring sense gratification. The devotees do not serve Krsna for any other purpose than to please Him.

The first step in devotional service is to develop faith, because the _sastras_ states that faithful persons are qualified to execute devotional service. In the beggining, therefore, we should hear scripture in the association of devotees so that our faith in the purport of the scripture will be strengthened. If we have not come to understand our relationship with Krsna, it is not possible to engage in devotional service. Srimad-Bhagwatam states that "Devotion, direct experience of the Supreme Lord, and detachment from other things - these three occur simultaneously for one who has taken shelter of the Supreme Personality of Godhead, in the same way that pleasure, nourishment, and relief from hunger come simultaneously and increasingly, with each bite for a person engaged in eating."

Detachment from material enjoyment and knowledge of the Absolute Truth appear simultaneously in the course of practicing devotional service. We canot become detached from material enjoyment and come to know the Absolute Truth without practicing devotional service. Devotional service is attained only in the association of devotees. While executing pure devotional service, there is no desire for religiosity, economic development, sense gratification, or liberation.
