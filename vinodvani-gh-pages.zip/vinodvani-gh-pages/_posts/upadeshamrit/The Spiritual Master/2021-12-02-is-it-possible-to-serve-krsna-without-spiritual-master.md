---
layout: post
title: Is it possible to serve Krsna without Spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "The spiritual master is not an ordinary human being. He is as good as the Supreme Lord. That is why the spiritual master is described as God. He is the object of love and devotion. Those who know tha the spiritual master is as good as the Supreme Lord are his genuine followers. Such followers are eligible for his mercy. Because the spiritual master, who is dear to Krsna, is pleased with unalloyed disciples, Krsna, his dearest friend, also becomes pleased with them."
---

It is not possible to worship Krsna without taking shelter at the spiritual master's feet. The spiritual master is not an ordinary human being. He is as good as the Supreme Lord. That is why the spiritual master is described as God. He is the object of love and devotion. Those who know tha the spiritual master is as good as the Supreme Lord are his genuine followers. Such followers are eligible for his mercy. Because the spiritual master, who is dear to Krsna, is pleased with unalloyed disciples, Krsna, his dearest friend, also becomes pleased with them.

​	Just consider how Hari, guru and the Vaishnavas are placed in succession. The spiritual master sits in the center, placing the Supreme Lord and the Vaishnvas on his lap. By firmly catching hold of the spiriutal master's lotus feet, we will automatically receive the mercy of the Lord and His devotees. If the spiritual master is pleased, Sri Hari and the Vaishanvas will also be pleased. If we cannot become unalloyed devotees of the spiritual master, if we cannot make the spiritual master our life and soul, then we will spoil everything and will not be able to receive the mercy of either the Lord or His devotees. Ultimately, we will be deceived and not attain the Lord's service. 
