---
layout: post
title: Is Sri Radharani the original spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "Sri Radhika, who is the *hladini* aspect of the Lord's internal energy, is the original spiritual master of all the devotees."
---

Sri Radhika, who is the *hladini* aspect of the Lord's internal energy, is the original spiritual master of all the devotees. She is even Krsna's spiritual master. As Her disciple, Krsna learns how to dance from Her. Pure devotees delonging to *rasas* other than the *madhurya-rasa* accept Sri Nitynanda Prabhu as their original spiritual master, but Sri Radhika is the original spiritual master of the *rasika devotees* belonging to the *madhurya-rasa*.  

