---
layout: post
title: Who follows the path of argumentation?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "As long as people accept the path of dry argument, they cannot find a bonafide spiritual master. The path of argument causes us to doubt the fact that there cannot be any truth superior to or separate from the spiritual master's teachings. Those who follows the path of argument disregard the spiritual master. The spiritual master alone is capable of removing all doubts and misconceptions. Dry argument has no foundation or standing. The truth received through disciplic succession does not change. The conception maintained in the argument-prone hearts of those who are envious of the spiritual master is disrespectful toward the guru and scriptures."
---

As long as people accept the path of dry argument, they cannot find a bonafide spiritual master. The path of argument causes us to doubt the fact that there cannot be any truth superior to or separate from the spiritual master's teachings. Those who follows the path of argument disregard the spiritual master. The spiritual master alone is capable of removing all doubts and misconceptions. Dry argument has no foundation or standing. The truth received through disciplic succession does not change. The conception maintained in the argument-prone hearts of those who are envious of the spiritual master is disrespectful toward the guru and scriptures.



















