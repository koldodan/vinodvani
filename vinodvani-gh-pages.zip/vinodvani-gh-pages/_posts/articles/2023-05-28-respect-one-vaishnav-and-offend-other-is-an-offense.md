---
layout: letters
title: Respect one vaishnav and offend another Vaishnav is an offense
categories: [articles]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: articles
description: "Maha Vaishnav is very dear and close to Lord. They perform service to the Supreme Lord in the cores of their heart. Supreme Lord lives in their body. Bhagwan himself has mentioned that I am under the control of a bhakt."
permalink: /respect-one-vaishnav-and-offend-other-is-an-offense/
date: 2023-05-28 00:00:00
---

<p style="text-align:center"> <b> বৈষ্ণব-অপরাধী শিষ্য ও সমর্থনকারী গুরুর গতি </b> </p>

Maha Vaishnav is very dear and close to Lord. They perform service to the Supreme Lord in the cores of their heart. Supreme Lord lives in their body. Bhagwan himself has mentioned that I am under the control of a bhakt.

We have to be very careful when dealing with bhakt. They are the one who can bestow Krishna bhakti in our hearts. Prabhupad Srila Bhakti Siddanta Saraswati thakur has mentioned that "we cannot give same respect to a guest and Vaishnav". Vaishnav is not a product of this material world. They are jivant-sadhu.

Even if we are not addressing vaishnav properly, we are commiting a vaishnav offence, what to talk about offending a vaishnav, which is a great offense.

Some decendants of Advaita Acharya would consider Advaita Acharya as Vishu and themselves as the sons of Vishnu. Thus considering themselves as the son's of Vishu, they used to defame Sri Gadadhar Pandit who is very dear to Sriman Mahaprabhu.

After the disappearence of Sri Advaita Prabhu, the so-called descendents of Advaita Acharya started to offend Sri Gadadhar Pandit. And by doing so, they have committed offence at the feet of Sri Advaita Prabhu and Srila Gadadhar pandit.

<p style="text-align:center">
<i>  
ये पापिष्ठ एक वैष्णवेर पक्ष हय । <br> </i>
<i>
अन्य वैष्णवेरे निन्दे, सेइ याय क्षय ।। <br>
</i> </p>

<p style="text-align:right"> <i>
 <b>Śrī Caitanya Bhāgavata (Madhyalīlā/13/160)</b> <br>
</i> </p>

Srila Vrindavan Das Thakur says that “the offender who takes side of one vaishnav and offend the other, his spiritual fortune is diminished.”

If we, in the pride of servant of a Maha Vaishnav, offend the other Maha Vaishnav, we will be devoid of Bhakti. We will not be able to attain the lotus feet of Lord Krishna.
