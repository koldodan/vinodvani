---
layout: post
title: What is the path of devotional service?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Any path that does not deal with service of Krsna is a nondevotional path. In pure service to Krsna, there is no desire other than the desire to please Krsna."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Any path that does not deal with service of Krsna is a nondevotional path. In pure service to Krsna, there is no desire other than the desire to please Krsna. Pure devotional service means to favorably cultivate Krsna consciousness. On the path of devotional service, giving Krsna happiness is the goal. However, on the path of nondevotional service, there is no question of seeking Krsna's happiness. The nondevotional path means seeking sense gratification.
