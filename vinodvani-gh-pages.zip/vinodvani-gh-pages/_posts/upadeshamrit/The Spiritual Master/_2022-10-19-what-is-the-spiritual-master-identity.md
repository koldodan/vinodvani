---
layout: post
title: What is the spiritual master's identity?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "The spiritual master is as good as Lord Hari. This does not mean that he is the supreme enjoyer. Rather, he is servitor God. Kisna remains the supreme object of service. The spiritual master is Krsna, yet an individual, topmost devotee of Krsna. Krsna is the object of all spiritual pastimes, and the spiritual master is the best among the supporters of those pastimes. There is no better devotee of Krsna in this world than the spiritual master. The spiritual master is one and not five or ten. He is an associate of Krsna. If associates of the Lord are separated from the Lord, then the Lord's supremacy is denied. This will result in revolution against the Lord. The spiritual master is not separate from the Lord."
---

The spiritual master is as good as Lord Hari. This does not mean that he is the supreme enjoyer. Rather, he is servitor God. Kisna remains the supreme object of service. The spiritual master is Krsna, yet an individual, topmost devotee of Krsna. Krsna is the object of all spiritual pastimes, and the spiritual master is the best among the supporters of those pastimes. There is no better devotee of Krsna in this world than the spiritual master. The spiritual master is one and not five or ten. He is an associate of Krsna. If associates of the Lord are separated from the Lord, then the Lord's supremacy is denied. This will result in revolution against the Lord. The spiritual master is not separate from the Lord.

Although the spiritual master and his worshipable Lord are one, they possess different characteristics. We should not attempt to eliminate the object of worship from its worshiper. The nondevotees conclude that the spiritual master's position is temporary, that he is only a means to an end and not eternally worshipable. By treating the spiritual master with such an abominable, low-class mentality, however, we will certainly go to hell.

Only Krsna can give Himself away; Krsna gives Himself to the spiritual master, and the spiritual master can then give Krsna away to others. The spiritual master alone can give away Krsna. That spiritual master who gives Krsna away to others resides eternally in Goloka Vrindavana. He was present before material time came into being and he will remain afterwards.

One who does not serve the spiritual master can never become a spiritual master himself, because the spiritual master teaches by his personal example how to serve guru and Krsna. A spiritual master is that person who eternally serves Krsna without fail. Every action the spiritual master performs is motivated by the desire to give Krsna pleasure. It is not the spiritual master's job to become God, because opposing God is an action of low-class, insignificant creatures.

The spiritual master can never be a nondevotee. He is self-realized and expert in allotting service to his disciples according to their particular qualifications. We will certainly achieve perfection if we receive such a great personality as our spiritual master. A spiritual master who encourages our sense gratification is not a spiritual master but a flatterer. A spiritual master who does not want to see his disciple progress approves everything his disciple does. A genuine spiritual master does not do so, because he is not a flatterer.

A spiritual master is not the disciple of his disciples, nor is he their order supplier. He does not flatter others, but carries Krsna's order to them. Lord Krsna is the Supreme Personality of Godhead, and there is no abomination in His existence. The spiritual master is an eternally liberated devotee of the Lord; he is devoid of anarthas.

The spiritual master imparts knowledge regarding the Lord's energies, glories, and identity. The spiritual master appears in this world to benefit us.

Our spiritual masters are eternally perfected beings. They have not attained perfection by the strength of their sadhana but were already perfect. If we do not serve such a spiritual master, we will become proud, remain far away from the humble vision of being lower than a blade of grass, and will not become established as Krsna's servants.

Despite receiving shelter at the feet of a bona fide spiritual master, we have not been able to take advantage of it because we do not pay guru-dakshina. To not pay guru-dakshina after having accepted the spiritual master's shelter is cheating. Do we feel that we belong to our spiritual master? If not, how will we serve? By serving the spiritual master with love and devotion as surrendered souls, all our anarthas and prejudices will be destroyed. Only through serving the guru can we achieve auspiciousness. To become indifferent to the spiritual master's service is the path of degradation.

Although the spiritual master is eternally worshipable, he is the embodiment of the Lord's service. He is the personification of devotional service to the Lord. The spiritual master is full of Krsna consciousness. He is always absorbed in thoughts of Krsna's service.

The spiritual master's name, form, qualities, and pastimes are all fully engaged in the Lord's service. Service to the Supreme Lord is his existence, his identity, his quality, and his pastime. He is expert in loving the Lord and an experienced teacher of loving devotional Service. The spiritual master is the captain to help us cross the ocean of material existence. He gives us both the holy name and love of God. He is the perfect guide, an acarya for teaching us how to chant the holy name and to give us knowledge of our relationship with Krsna.
