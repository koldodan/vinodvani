---
layout: post
title: Is a Kanishtha-adhikari superior to a karmi or jyani?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'A kanishtha-adhikari is superior because he has adopted the path of devotion, the path of auspiciousness. Karmis and jyanis donot have such fortune. Kanishtha-adhikaris are generally engaged in Deity worship. By serving the Deity, the guru, and the Vaishnavas, and by serving the Lords holy name, living entities attain supreme auspiciousness. Sri Chaitanyadeva has said that the tongue of anyone who utters the name of Krsna even once is the best of all. A Kanishtha-adhikari who worships the Deity with mantras consisting of the Lords holy names is superior to the best of pious fruitive workers in this world.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

A *kanishtha-adhikari* is superior because he has adopted the path of devotion, the path of auspiciousness. *Karmis* and *jyanis* donot have such fortune. *Kanishtha-adhikaris* are generally engaged in Deity worship. By serving the Deity, the guru, and the Vaishnavas, and by serving the Lord's holy name, living entities attain supreme auspiciousness. Sri Chaitanyadeva has said that the tongue of anyone who utters the name of Krsna even once is the best of all. 

A *Kanishtha-adhikari* who worships the Deity with mantras consisting of the Lord's holy names is superior to the best of pious fruitive workers in this world. He is also better than any *jyanis*, because however great the *karmis* and *jyanis* may be, they do not have faith in the eternal service of the Absolute Truth, Vishnu. Therefore, even though they claim to be Vedic followers, they are actually atheists, whereas the worshipers of Vishnu regardless of their level of advancement in the kingdom of *bhajan* are faithful to the Deity form of the Absolute Truth because they have heard of His glories from the mouth of their spiritual master. 

The thousands of *karmis* who have opened innumerable hospitals, old age homes, centers for the poor, and schools, and the thousands of *jyanis* who have engaged in meditation and undergone severe austerities are insignificant compared to a single *kanishtha-adhikari* Vaishnav ringing the bell once before the Lord's Deity. This is not sectatianism but the plain trith. Atheists can never understand the confidential purport of my words, so they sometimes openly and other times covertly criticize devotional service.
