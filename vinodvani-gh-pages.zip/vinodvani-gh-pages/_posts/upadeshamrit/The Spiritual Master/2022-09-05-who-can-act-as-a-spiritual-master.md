---
layout: post
title: Who can act as a spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'Only a devotee of Krsna who knows the service of Krsna can act as guru. Since Karmis, jnanis and impersonalists are nondevotees, they can never become gurus. Only one who worships the Personality of Godhead is able to become a spiritual master. Those who think proudly that they are Krsnas servants cannot become spiritual masters unless they proudly identify themselves as disciples of a disciple.'
---

Only a devotee of Krsna who knows the service of Krsna can act as guru. Since _Karmis_, _jnanis_ and impersonalists are nondevotees, they can never become gurus. Only one who worships the Personality of Godhead is able to become a spiritual master. Those who think proudly that they are Krsna's servants cannot become spiritual masters unless they proudly identify themselves as disciples of a disciple. As long as we are proud of being vaishnavas, we cannot become guru. A person who acts as a guru never claims to be a Vaishnava or spiritual master. My spiritual master never considered himself a Vaishnava. One who calls himself a Vaishnava is branded a non-Vaishnava.

**Srila Bhaktivinoda Thakura has sung:**

```
'ami to vaisnava', e buddhi hoile, amani na ho'bo ami
pratisthasa asi', hrdoya dusibe, hoibo niraya-gami

tomara kinkora, apane janibo, 'guru'-abhimana tyaji'
tomara ucchistha, pada-jala-renu, sada niskapate bhaji

'nije srestha' jani, ucchistthadi dane, ho'be abhimana bhara
tai sisya taba, thakiya sarvada, na loibo puja ka'r
```

If I think I am a Vaishnava, I shall look forward to receiving other's respect. If the desire for fame and reputation pollutes my heart, I will certainly go to hell. I will give up the pride of being a guru and consider myself your eternal servant. I will sincerely accept your remnants and the water that has washed your lotus feet. By giving others the remnants of my food, I will think myself superior and be burdened by the weight of false pride. Therefore, always remaining your surrendered disciple, I will not accept worship from anyone else. (_Kalyana Kalpataru_).

Only a pure devotee can be a spiritual master. A great personality sees the spiritual master everywhere. Such a person is himself qualified to become a spiritual master because he can induce everyone to become Krsna conscious. Unless we are devotees ourselves, we cannot make others devotees. Therefore, to become guru, we must become devotees of Krsna. We must always engage in Krsna's service with all our senses. We are not qualified to act as spiritual master unless we are ourselves staunch disciples of our spiritual master.

A pure devotee thinks himself to be humbler than a blade of grass and more tolerant than a tree. He never says he has served his spiritual master enough and therefore no longer needs to offer service to his guru. He never thinks it is time for him to become guru. Although he may indeed act as spiritual master, he never becomes proud of it.
