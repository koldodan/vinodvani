---
layout: post
title:  "How can we achieve Lord Hari"
date:   2021-02-17 20:41:43 -0500
categories: "upadeshamrit"
author: prabhupada
tags: association
permalink: /:categories/How-can-we-achieve-Lord-Hari
---



We should seek to associate only with Krsna's devotees. Krsna's devotees are auspicious, eternal, and compassionate. Bad association -association without Krsna consciousness-is harmful. Thus, we should not respect anything unrelated to Krsna's devotional service.

I am astonished to see that despite hearing so much hari-katha you still admire material life and attachment. This is unfortunate. We cannot attain Krsna by bad association. Remember, we achieve Lord Hari by associating with devotees and renouncing the association of materialists.

If we Can see all material objects in relation to Krsna, then they cannot harm us. The world is full on ingredients for the Lord's service. If, however, we consider the Lord's paraphernalia as intended for our own enjoyment, our material attachment will increase and we will have to suffer material existence.

