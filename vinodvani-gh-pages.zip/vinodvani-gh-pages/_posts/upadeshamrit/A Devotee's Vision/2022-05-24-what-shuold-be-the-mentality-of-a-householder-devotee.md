---
layout: post
title: What should be the mentality of a householder devotee?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "A householder devotee must remember that his house belongs to Krsna and he himself is a pet dog that Krsna maintains. One should serve Krsna with all that he possesses, knowing well that Krsna is the master of his household."
---

A householder devotee must remember that his house belongs to Krsna and he himself is a pet dog that Krsna maintains. Sri Bhaktivinoda Thakur writes, "Oh Lord! I do not know what is good and what is bad. I simply engage in Your Service. I guard objects that belong to you." One should serve Krsna with all that he possesses, knowing well that Krsna is the master of his household.

​	Materialists who are attached to the house do not consider Lord Hari and the spiritual master worshipable. They see the spiritual master and the Lord's Deity form as ordinary objects. Only those who can offer everything to Krsna by giving up material attachment are able to chant Krsna's holy name. Chanting the holy name of Krsna is not possible unless one gives up attachment for family life and offers everything to Krsna's service.





















