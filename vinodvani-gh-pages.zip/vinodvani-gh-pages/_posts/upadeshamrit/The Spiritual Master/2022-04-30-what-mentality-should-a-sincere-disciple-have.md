---
layout: post
title: What mentality should a sincere disciple have?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "Sincere disciples should be completely devoted to their guru. They should know their spiritual master to be as good as God and the only object of theit love and devotion. The spiritual master is my eternal master and I am his eternal servant."
---

Sincere disciples should be completely devoted to their guru. They should know their spiritual master to be as good as God and the only object of their love and devotion. "The spiritual master is my eternal master and I am his eternal servant."; this is how a disciple thinks. Service to spiritual master is a disciple's life, ornament, and means of survival. Disciples do not know anything except their spititual master. They always think of their spiritual master while eating, sleeping, dreaming, and serving. They are fully convinced that the spiritual master is the fully independent Personality of Godhead.

​	A sincere disciple has the following mentality; "Even if my spiritual master does not accept service from such an unqualified person as myself, I will always be prepared to render unalloyed service at his feet with body, mind and words. If he kicks me, I will think it is because of my incompetence; his kick will come because of my faults. He is always right. May temporary sense desires not distract me from his service even for a moment. My only prayer is that my spiritual master, mercifully accepts my service. I pray never to fall into bad association or to fall away from his lotus feet. My only solace is that my spiritual master is more merciful to unqualified persons like me. With a desire to achieve his causeless mercy, I will become greedier for his service."

















