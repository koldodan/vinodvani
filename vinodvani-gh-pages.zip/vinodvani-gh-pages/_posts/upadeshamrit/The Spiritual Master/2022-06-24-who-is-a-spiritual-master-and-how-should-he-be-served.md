---
layout: post
title: Who is a spiritual master and how should he be served?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "The guru and Vaishnavas are the transcendental home of the Supreme Lord. The Lord does not manifest just anywhere. He appears and remains in the hearts of guru and the vaishnavas. Many people want to see the Lord, but they do not know that the Lord's *darshan* can be had only through the spiritual master's *darshan*. It is not possible to begin devotional service without a spiritual master. The Spiritual master is the via media between us and Krsna's lotus feet. This is Krsna's mercy. He sends His topmost servant or Vaishnav into this world to deliver everyone. Thus the spiritual master is the personification of that causeless mercy."
---

The guru and Vaishnavas are the transcendental home of the Supreme Lord. The Lord does not manifest just anywhere. He appears and remains in the hearts of guru and the vaishnavas. Many people want to see the Lord, but they do not know that the Lord's _darshan_ can be had only through the spiritual master's _darshan_. It is not possible to begin devotional service without a spiritual master. The Spiritual master is the via media between us and Krsna's lotus feet. This is Krsna's mercy. He sends His topmost servant or Vaishnav into this world to deliver everyone. Thus the spiritual master is the personification of that causeless mercy.

​ The spiritual master is our ever well-wisher. Therefore, it is not enough simply to serve him with awe and reverence from a distance. Instead, we must serve him with firm conviction and love. Then only will we attain perfection. The spiritual master is more important to us than Lord Krsna. Sri Gaurangadev is the spiritual master of all the gurus. He revealed to us that even though the spiritual master is nondifferent from the Supreme Lord, he is the Lord's principal devotee. We cannot serve the Lord without our guru's mercy, becuase our guru is the Lord's topmost devotee. The living entities have no way to achieve auspiciousness other than to serve the spiritual master.
