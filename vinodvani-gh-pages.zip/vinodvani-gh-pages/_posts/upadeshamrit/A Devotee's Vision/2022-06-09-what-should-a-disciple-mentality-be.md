---
layout: post
title: What should a disciple's mentality be?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "Our object of hearing should be glorification of the spiritual master. We must humbly follow the spiritual master's orders without any reservation. For this we should gladly accept any necessary inconvenience. This is how a disciple thinks."
---

Our object of hearing should be glorification of the spiritual master. We must humbly follow the spiritual master's orders without any reservation. For this we should gladly accept any necessary inconvenience. This is how a disciple thinks.

​	The spiritual master glories the Absolute Truth. A disciple must hear his words attentively and then apply them in his own life.

























