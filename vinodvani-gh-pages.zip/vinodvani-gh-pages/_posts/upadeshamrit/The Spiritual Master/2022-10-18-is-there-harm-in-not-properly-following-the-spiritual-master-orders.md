---
layout: post
title: Is there harm in not properly following the spiritual master's orders?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "By not following the orders of the all-auspicious spiritual master the living entities invite suffering. Such disobedience or neglect increases their material desires and they go to hell after death. Anyone who does not obey his spiritual master's order is certainly a materialist and offender. Those who transgress the spiritual master's orders take birth as pigs. Those who are too attached to material enjoyment cannot attain benefit because they do not serve the spiritual master with heart and soul, even though, due to good fortune, they have received a bonafide guru. Since they do not understand the value of such an invaluable gift they consider the temporary material world eternal and suffer birth after birth."
---

By not following the orders of the all-auspicious spiritual master the living entities invite suffering. Such disobedience or neglect increases their material desires and they go to hell after death. Anyone who does not obey his spiritual master's order is certainly a materialist and offender. Those who transgress the spiritual master's orders take birth as pigs. Those who are too attached to material enjoyment cannot attain benefit because they do not serve the spiritual master with heart and soul, even though, due to good fortune, they have received a bonafide guru. Since they do not understand the value of such an invaluable gift they consider the temporary material world eternal and suffer birth after birth.
