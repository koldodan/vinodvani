---
layout: post
title: How should I treat my spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "Serve your spiritual master with love and devotion just as you do Krsna. Consider the spiritual master as good as the Supreme Lord. Do not think him inferior to the Lord in any way. It is disciple's duty to treat, worship, and serve the spiritual master as if he were God. If a disciple does not do so, he will fall down from his position as a disciple."
---

Serve your spiritual master with love and devotion just as you do Krsna. Consider the spiritual master as good as the Supreme Lord. Do not think him inferior to the Lord in any way. It is disciple's duty to treat, worship, and serve the spiritual master as if he were God. If a disciple does not do so, he will fall down from his position as a disciple. Only those who consider the spiritual master nondifferent from the Supreme Lord can understand the confidential purport of the Scriptures, chant Hari's Holy Name, and preach *hari-katha*. To teach about His own service Lord Krsna appears in the form of the spiritual master. If we are fortunate enough, we can understand this flawless scriptural verdict. Otherwise, we will remain doubtful and continue to drown in the ocean of material existence. 

​	The spiritual master is neither the predominanting absolute nor the original predominated absolute. He is manifestation of the original predominated absolute. Lord Krsna is the worshipable God and the spiritual master is the worshiper God. Lord Krsna is the predominating absolute and the spiritual master is the predominated absolute. Because the spiritual master, who is the worshiper God, is the personification of service to Krsna Himself, he is most dear to Krsna. This is the special characteristic of the science relating to the spiritual master. Sri Krsna is the energetic and the spiritual master is His complete energy. The spiritual master is not an ordinary human being. He is the master of the living beings. The spiritual master is the supreme consciousness and a manifestation of the Lord's spiritual energy. But the living entities as minute spiritual spiritual sparks belong to the Lord's marginal energy and are part and parcel of the Lord.















