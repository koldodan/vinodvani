---
layout: post
title: Who is qualify to become a spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: Those who consider themselves disciples of a disciple are qualified to become spiritual masters.
---

Those who think themselves Vaishnvas are not Vaishnavas, Those who think themselves gurus or great personalities are not qualified to become gurus. Those who consider themselves disciples of a disciple are qualified to become spiritual masters. Only one who has unflinching faith in the Supreme Lord and the spiritual master is able to act as a guru.

