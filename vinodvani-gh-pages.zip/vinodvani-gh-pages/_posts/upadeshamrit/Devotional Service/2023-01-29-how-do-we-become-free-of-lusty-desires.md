---
layout: post
title: How do we become free of lusty desires?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Having lusty desires means we want to enjoy sense gratification. It is the living entity's duty to serve the Supreme Personality of Godhead. Aversion to the Lord's service drowns us in an ocean of material misery. If we wish to become liberated from that misery, we must serve the non envious servants of Krsna. That is the only remedy. Krsna's servants alone can protect us from lust. We tend toward lustiness because we are not inclined to serve Krsna, the transcendental Cupid. The slightest disturbance in the attempt to satisfy that lust makes us angry. Lusty desire is the mother of all sense gratification. The only occupation of a pure spirit soul is to gratify the transcendental Cupid's senses. One who acts for this purpose finds the seed of lusty desires destroyed by his service and surrender to Sri Krsna."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Having lusty desires means we want to enjoy sense gratification. It is the living entity's duty to serve the Supreme Personality of Godhead. Aversion to the Lord's service drowns us in an ocean of material misery. If we wish to become liberated from that misery, we must serve the non envious servants of Krsna. That is the only remedy. Krsna's servants alone can protect us from lust. We tend toward lustiness because we are not inclined to serve Krsna, the transcendental Cupid. The slightest disturbance in the attempt to satisfy that lust makes us angry. Lusty desire is the mother of all sense gratification. The only occupation of a pure spirit soul is to gratify the transcendental Cupid's senses. One who acts for this purpose finds the seed of lusty desires destroyed by his service and surrender to Sri Krsna.
