---
layout: post
title: Is praying to the Lord for a healthy life deterimental to devotional service?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'Whatever way Lord Krsna is pleased to keep us we should accept without reservation. To desire sound health in order to worship the Lord is favorable for devotional service. To desire sound health in order to engage in sense gratification is not acceptable. Devotees do not wish to follow the path of the nondevotees, who demand that the Lord serve them. Rather, they pray for good health at the lotus feet of Sri Nrisimhadeva, who destroys all obstacles, in order to worship Krsna, and this is certainly favorable.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Whatever way Lord Krsna is pleased to keep us we should accept without reservation. To desire sound health in order to worship the Lord is favorable for devotional service. To desire sound health in order to engage in sense gratification is not acceptable. Devotees do not wish to follow the path of the nondevotees, who demand that the Lord serve them. Rather, they pray for good health at the lotus feet of Sri Nrisimhadeva, who destroys all obstacles, in order to worship Krsna, and this is certainly favorable.
