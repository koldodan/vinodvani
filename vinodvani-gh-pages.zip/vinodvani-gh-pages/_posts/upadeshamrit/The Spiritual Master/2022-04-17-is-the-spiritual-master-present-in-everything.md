---
layout: post
title: Is the Spiritual master present in everything?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "My spiritual master is the one who always personally demonstrates how to serve Krsna throughout my life. He is reflected in the hearts of all living entities, and he is all objects as the Lord's subordinate. Thus he is present in every item"
---

In order to bestow mercy on me, my spiritual master appears before me in varous forms. They are all manifestations of my initiating spiritual master, who imparts transcendental knowledge. The light of the *Jagat-guru* is reflected in various objects. My spiritual master is reflected in each and every object. Worshipable Krsna is half and worshiper Krsna is the other half. Their combined pastimes are complete. Krsna is the complete manifestation of the object of worship, and my spiritual master is the complete manifestation of the worshiper. All cognizant objects in which the refelection of transcedence falls are my spiritual master in different forms. My spiritual master is the one who always personally demonstrates how to serve Krsna throughout my life. He is reflected in the hearts of all living entities, and he is all objects as the Lord's subordinate. Thus he is present in every item.



