---
layout: post
title: Whose association should we desire?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

Our spiritual master has declared that karma and gyan are the religion of cheaters. We should give up those two paths and follow the path of devotional service. To do so, we should associate with those who traverse the path of devotion. It is essential to associate with devotees superior to us. Our most cherished object is the dust of Sri Rupa Goswami's lotus feet. Sri Rupa Goswami establish Lord Chaitanya's mission in this world.

Our devotional service will be enhanced in the association of devotees. *Karmis, gyanis, and yogis* are non-devotees. Hence they cheat themselves and others. Their association should be rejected. All association apart from devotee association is inauspicious.



