---
layout: post
title: Should we give up bad association?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

We are servants of the Supreme Lord. Why should we become materialists? Material enjoyment brings distress. Sense objects, which we perceive through *form, taste, smell, touch, and sound* perpetually troubles us. We should not become material enjoyers. Sri Gaurangadeva said that one who wants to worship the Lord should never see a *materialist*.

If we surround ourselves with sense gratification, we will forget the Lord and tend to consider His devotees insignificant. A person who is travelling on the devotional path should not see a materialist's face. Not only. should he not see a materialist, he should not see even an associate of a materialist. As the physician for our material disease, Sri Gaurasundara, advised, "Do not associate with materialists, do not associate with materialists, do not associate with the materialists."

