---
layout: post
title:  "Should we renounce the association of those greedy for money?"
date:   2021-03-02 08:41:43 -0500
categories: "upadeshamrit"
author: "Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur"
permalink: /:categories/Should-we-renounce-the-association-of-those-greedy-for-money
description: Wealth is the source of all anarthas. It is the best if wealth is used in Krsna's service.
tags: association
---


Wealth is the source of all anarthas. It is the best if wealth is used in Krsna's service. Otherwise, it will ruin our lives and bind us to material existence. Pious devotees should never be greedy for temporary wealth. We should hanker only after eternal wealth, spiritual life. May persons who desire auspiciousness be free of attachment to wealth, because as long as we are materially attached, we will be useless. Please bless me so the for the rest of my life, I will not have to see the faces of materialists greedy for wealth. 

