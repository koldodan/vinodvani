---
layout: post
title: Should we give up bad association?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

Not everyone is fortunate enough to understand a Vaishnav's activities and behaviour. It is good for me if, due to ignorance, someone looks upon me with a crooked glance. My only distress is that some people go to hell along with their ancestors by becoming envious of my eternally worship able spiritual master and the Vaishnavas.

It is the duty of intelligent persons to perfect their human life. These persons should know that it is dangerous to associate with pseudo-devotees. Those who accept the path of material enjoyment or dry renunciation are walking, not toward devotional service, but in the opposite direction.

There are thirteen unauthorized *sampradayas*, such as the *aul, baul, etc.* Their association is bad. If one considers such abominable association along with association with hypocrites and women, good, then he will inevitably become degraded. Please do not associate with such misguided people. Associating with non-devotees ensures one's degradation.

Material enjoyers or people who are fond of material enjoyment are uninitaited and devoid of transcendental knowledge. They are pseudo-devotees or non-devotees. Please stop associating with such non-devotees and make progress in spiritual life in the association of devotees and the *shastras*.



