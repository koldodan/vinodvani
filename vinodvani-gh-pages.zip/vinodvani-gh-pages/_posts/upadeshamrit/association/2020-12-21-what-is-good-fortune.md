---
layout: post
title: What is good fortune?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

After traveling through the universes from time immemorial, when a living entity's material existence is about to come to an end, he develops a slight taste for devotional service because he receives the association of a devotee. This is the definition of good fortune.
