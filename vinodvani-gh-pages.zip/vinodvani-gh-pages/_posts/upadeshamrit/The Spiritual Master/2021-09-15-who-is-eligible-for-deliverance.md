---
layout: post
title: Who is eligible for deliverance?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
---

As soon as we forget the Lord, various mundane thoughts and sense desires swallow us. The most merciful Sri Krishna is always ready to protect us from such danger provided we depend on Him completely. Lord Krsna saves the living entities in the form of the spiritual master. The spiritual master is the personification of Krsna's mercy. The spiritual master, Krsna's representative, appears in this world to deliver th e living entities from material existence and bring them back to Godhead. Only those fortunate souls who eagerly accept the mercy of such a spiritual master become liberated and go back to the eternal abode of peace.

