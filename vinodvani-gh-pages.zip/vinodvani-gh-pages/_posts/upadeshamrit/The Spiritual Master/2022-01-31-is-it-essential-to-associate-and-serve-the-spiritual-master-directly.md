---
layout: post
title: Is it essential to associate and serve the spiritual master directly?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "We should certianly communicate directly with the spiritual master. Those who do not wish to serve and associate with their spiritual master personally are bound to be cheated."
---

We should certianly communicate directly with the spiritual master. Those who do not wish to serve and associate with their spiritual master personally are bound to be cheated. Direct communication with guru is the first step on the path of divine service. 

​	We should serve the manifestations of guru in every entity. If we cannot serve the guru, we cannot serve anyone. I must not hear anything until my divine master, Sri Gurudeva, authorizes me to hear it.





 

