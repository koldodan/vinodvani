---
layout: post
title: What is actual happiness?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "The sastra declare that all hapiness emanates from the Supreme Brahman. Lord Krsna is the embodiment of ecstatic love. He is the personification of complete peace."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

The _sastra_ declare that all hapiness emanates from the Supreme Brahman. Lord Krsna is the embodiment of ecstatic love. He is the personification of complete peace. The _Brahma-samhita 5.1_ states, "Govinda, Krsna, is the cause of all causes. He is the primial cause, and He is the very form of eternity, knowledge, and bliss." Elsewhere, _shastra_ states that there is no hapiness to be found in insignificant objects. Material happiness brings no satiation because it is incomplete. The Absolute Truth is the only reservoir of happiness. Therefore, only by engaging in the service of blissful Krsna can the living entity become completely happy.
