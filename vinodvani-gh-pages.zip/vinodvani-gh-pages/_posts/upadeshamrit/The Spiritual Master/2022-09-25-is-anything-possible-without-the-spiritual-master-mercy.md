---
layout: post
title: Is anything possible without the spiritual master's mercy?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "I am blinded by ignorance, so who will show me the right path? Who will impart to me real knowledge? Everything is attained simply by the spiritual master's mercy. We are fallen conditioned souls and the spiritual master is our only shelter. A spiritual master is he who always serves the Supreme Lord. The spiritual master is the servitor God. Are we looking at him in that way? If not, how can we expect to benefit from his association."
---

I am blinded by ignorance, so who will show me the right path? Who will impart to me real knowledge? Everything is attained simply by the spiritual master's mercy. We are fallen conditioned souls and the spiritual master is our only shelter. A spiritual master is he who always serves the Supreme Lord. The spiritual master is the servitor God. Are we looking at him in that way? If not, how can we expect to benefit from his association.
