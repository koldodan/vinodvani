---
layout: post
title: How do pure devotees respect their spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "The spiritual master is known to ordinary people in one form and to his intimate devotees in another. The pure devotees recognize their spiritual master as the supreme well-wisher, as most dear to Krsna, and as the object of their love and devotion, the object of their eternal service and their life and soul. The spiritual master is most dear to and nondifferent from Krsna. It is not possible to achieve Krsna's service without serving the spiritual master. Only those who serve the spiritual master can be considered Vaishnavas."
---

The spiritual master is known to ordinary people in one form and to his intimate devotees in another. The pure devotees recognize their spiritual master as the supreme well-wisher, as most dear to Krsna, and as the object of their love and devotion, the object of their eternal service and their life and soul. The spiritual master is most dear to and nondifferent from Krsna. It is not possible to achieve Krsna's service without serving the spiritual master. Only those who serve the spiritual master can be considered Vaishnavas.

​	We cannot see the spiritual master's lotus feet with sinful eyes. Considering the spiritual master an ordinary human being is a hellish mentality. The spititual master is not an insignificant creature; he is not an ordinary human being. He is the Supreme Lord and is very dear to the Lord. He is a great personality, an exalted devotee, and an *acarya* who can award Hari's holy names to others.

















