---
layout: post
title: Can we immediately attain Srimati Radhika's lotus feet?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: It is not that Sri Radharani is not present. Even now we can attain Her lotus feet and service. If we can see the beauty of Sri Radharani's toenails at our spiritual master's lotus feet, we will no longer think about where we will find Sri Radharani. If we are fortunate enough, we can attain service to and *darshana* of Sri Radharani's lotus feet in the *darshana* of our spiritual master's lotus feet, because he is nondifferent from Sri Radha and very dear to Her.
---

It is not that Sri Radharani is not present. Even now we can attain Her lotus feet and service. If we can see the beauty of Sri Radharani's toenails at our spiritual master's lotus feet, we will no longer think about where we will find Sri Radharani. If we are fortunate enough, we can attain service to and *darshana* of Sri Radharani's lotus feet in the *darshana* of our spiritual master's lotus feet, because he is nondifferent from Sri Radha and very dear to Her.

​	In *madhurya-rasa*, the spiritual master is an intimate *gopi* friend of Sri Radharani. He is nondifferent from the daughter of Vrshabahanu. Only the sincere disciples of a spiritual master in *madhurya-rasa* can attain the *darshana* of the beauty if Sri Radha rani's toenails in the form of their spiritual master. Only the intimate disciples of a spiritual master can realize that their spiritual master is a manifestation of Sri Radha or that he is nondifferent from the daughter of King Vrshabhanu.















