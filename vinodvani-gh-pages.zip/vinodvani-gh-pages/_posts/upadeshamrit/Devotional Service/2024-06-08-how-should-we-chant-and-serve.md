---
layout: post
title: How should we chant and serve?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Until we develop firm faith that service to Lord Vishnu and the Vaishnavas is topmost, we cannot attain auspiciousness. Therefore, we should first serve the Deity with firm faith and chant the Lord holy name simply for His pleasure."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Until we develop firm faith that service to Lord Vishnu and the Vaishnavas is topmost, we cannot attain auspiciousness. Therefore, we should first serve the Deity with firm faith and chant the Lord's holy name simply for His pleasure. If we have some ulterior motive, we will not be able to engage in the Lord's service. Therefore, we request everyone: O friends! Give up all sinful activities and engage in the Lord's service for His pleasure. What appears auspicious in this world is not actually auspicious. You do not need to artificially dress as a Narada as if you were in a drama. Worship the Lord and chant His holy name simply to please Hi,. This will award you auspiciousness.
