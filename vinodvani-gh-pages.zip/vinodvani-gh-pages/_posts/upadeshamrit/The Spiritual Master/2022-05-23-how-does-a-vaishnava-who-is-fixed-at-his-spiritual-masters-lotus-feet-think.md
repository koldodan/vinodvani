---
layout: post
title: How does a Vaishnav who is fixed at his spiritual master's lotus feet think?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'Unless I realize that all the living entities in the world are worshipable, I cannot offer my respectful obeisances to my spiritual master. My spiritual master is the spiritual master of the entire world. People who are envious of my spiritual master are also envious of the Supreme Lord and of every other human being. Until I feel this conviction in my heart, I cannot become a real servant of my spiritual master and cannot surrender at his lotus feet.'
---

Unless I realize that all the living entities in the world are worshipable, I cannot offer my respectful obeisances to my spiritual master. My spiritual master is the spiritual master of the entire world. People who are envious of my spiritual master are also envious of the Supreme Lord and of every other human being. Until I feel this conviction in my heart, I cannot become a real servant of my spiritual master and cannot surrender at his lotus feet. Neither will I be able to understand that I am the most insignificant created being. Therefore, I will not be able to chant the holy name of Hari thinking of myself as lower than a straw in the street and more tolerant than a tree. I will not be devoid of the desire for respect or prepared to offer respect to others. If I respect my spiritual master properly, I will be able to respect the whole world. This will make it possible for me to become free of the desire to receive respect for myself and thus able to glorify Lord Hari constantly.
