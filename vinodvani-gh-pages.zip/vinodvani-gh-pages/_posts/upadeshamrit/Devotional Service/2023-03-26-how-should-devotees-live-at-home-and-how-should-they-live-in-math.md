---
layout: post
title: How should devotees live at home? How should they live in the Matha?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Whether they live in Matha or outside as householders, devotees should live externally like materialists while remaining internally fixed in devotional service. Do not dress simply like a devotee externally while internally remaining attached to material enjoyment - house, wealth, and fame. This is duplicity, and duplicity is extremely detrimental to devotional service."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Whether they live in Matha or outside as householders, devotees should live externally like materialists while remaining internally fixed in devotional service. Do not dress simply like a devotee externally while internally remaining attached to material enjoyment - house, wealth, and fame. This is duplicity, and duplicity is extremely detrimental to devotional service. Pseudo renunciation, monkey renunciation, is abominable. Those who practice it misguide the living entities from the path of devotional service and lead them to hell. Our only duty is to follow the ideal example and teachings of Raghunath Das Goswami. You should not make yourself a show-bottle devotee and become a false renunciant. For the time being, reside in the material world in a befiting way, but do not become attached to it. Within your heart, you should keep yourself very faithful, but externally you may behave like an ordinary man. Thus Krsna will soon be very pleased and deliver you from clutches of Maya.

(*Caitanya-caritamrita Madhya 16.238-39*)
