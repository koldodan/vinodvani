---
layout: post
title: Is it the spiritual master fully independent?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "My spiritual master is completely independent. He is not dependent on the mercy of anyone in this world. His good wish is that everyone sincerely worships Hari."
---

My spiritual master is completely independent. He is not dependent on the mercy of anyone in this world. His good wish is that everyone sincerely worships Hari. He considers giving others instructions on how to satisfy krsna's senses as the best form of compassion. He considers teaching others to fuel their sense gratification envy not mercy.









