---
layout: post
title: Can we save ourselves?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "Instead, devotees know that Krsna is their protector. Why should we be afraid? We should maintain this understanding taught by the great devotee, Prahlada. As soon as we become indifferent to *hari-katha* and become less dependent on the Lord, we will become captured by various sinful motives and false ego. Then we will be in danger."
---

"I will protect myself": this is what a non devotee demon thinks. This concept will certainly get us into trouble. Instead, devotees know that Krsna is their protector. Why should we be afraid? We should maintain this understanding taught by the great devotee, Prahlada. As soon as we become indifferent to *hari-katha* and become less dependent on the Lord, we will become captured by various sinful motives and false ego. Then we will be in danger.



















