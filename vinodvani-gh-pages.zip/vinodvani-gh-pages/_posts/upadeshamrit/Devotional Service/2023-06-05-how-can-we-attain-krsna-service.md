---
layout: post
title: How can we attain Krsna's service?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'We are souls surrendered to Krsna. We are under the shelter of the spiritual masters lotus feet. It is not possible to see the Lord with our present material eyes. The Lords pure devoteees always see Him through eyes anointed with devotion. We are conditionaed souls.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

We are souls surrendered to Krsna. We are under the shelter of the spiritual master's lotus feet. It is not possible to see the Lord with our present material eyes. The Lord's pure devoteees always see Him through eyes anointed with devotion. We are conditionaed souls. Our conception as servants of the Supreme Lord will be awakened if we can simply carry the shoes of Sri Chaitanyadeva's servants. By the mercy of devotees, we will receive spiritual eyes anointed with devotion and then, by the spiritual master's mercy, attain realization of and service to Krsna.
