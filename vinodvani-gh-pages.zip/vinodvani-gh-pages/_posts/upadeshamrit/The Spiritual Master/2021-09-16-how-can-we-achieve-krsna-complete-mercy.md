---
layout: post
title: How can we achieve Krsna's complete mercy?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
---

We can attain Krsna's complete mercy simply by becoming qualified to be counted among the servants of Vrshbhanu's daughter as Sri Rupa's servant. We can achieve such good fortune simply by becoming a servant or particle of dust at the lotus feet of the guru who is a staunch follower of Sri Rupa. That is why it is said that we need to become lower than straw in the street. If we wish to become lower than straw in the street, we have to consider ourselves the guru's servant and sere the holy name without reservation.
