---
layout: post
title: What is the result of taking shelter at the feet of a bonafide spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "By taking shelter of a bonafide spiritual master a living entity can make the highest advancement on the path of worshiping Hari. By serving guru and Krsna a living entity's mundane conceptions are destroyed and he attains Goloka. As a result of sincere service a living entity can attain an equal position with liberated souls - even eternally liberated souls. The spiritual master, who is non different from Lord Nityananda, is not a lump of flesh and blood. By taking shelter at his lotus feet, a living entity can attain freedom from the threefold material miseries."
---

By taking shelter of a bonafide spiritual master a living entity can make the highest advancement on the path of worshiping Hari. By serving guru and Krsna a living entity's mundane conceptions are destroyed and he attains Goloka. As a result of sincere service a living entity can attain an equal position with liberated souls - even eternally liberated souls. The spiritual master, who is non different from Lord Nityananda, is not a lump of flesh and blood. By taking shelter at his lotus feet, a living entity can attain freedom from the threefold material miseries.
