---
layout: post
title: Should we give up material enjoyment [karma] and renunciation [jyana]?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "MahaPrabhu instructed us to give up both material enjoyment and dry renunciation. Material enjoyment is defined as accepting mundane form, taste, smell, sound, and touch through our eyes, tongue, nose, ears, and skin as pleasureable. Although there is some apparent momentary happiness in material enjoyment, we later discover that sense gratification comes with more distress than happiness."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

MahaPrabhu instructed us to give up both material enjoyment and dry renunciation. Material enjoyment is defined as accepting mundane form, taste, smell, sound, and touch through our eyes, tongue, nose, ears, and skin as pleasureable. Although there is some apparent momentary happiness in material enjoyment, we later discover that sense gratification comes with more distress than happiness. That's why renunciation is more glorious than enjoyment. Renunciation or detachment, is good, but if in the process of detachment we also renounce the Supreme Lord, then such renunciation is simply another form of material enjoyment. The conception of those who consider the material world false or as worthless as the stool of a crow is defective, because that conception denies the omnipotent Lord's energies. The material world is factual, although everything in it is temporary. This is the conclusion of those who are conversant with *Vedanta*. 

​	Just as material enjoyment does not allow one to understand the relationship between the Supreme Lord and the visible objects because he deceitfully sees himself as the enjoyer, renunciation does not give one the opportunity to understand that everything in this world is meant for the Lord's service. Thus he disrespects objects related to the Supreme Lord.

​	Material objects are this world's opulence. Objects that have form, taste, and so on, are the goal of the senses led by eyes. The senses will never become averse to them; they will never retire from pursuing them. Although certain renunciants sometimes Dres themselves as if they were controlling their external senses; their mind, the king of the senses, remains absorbed in material enjoyment even without their knowledge. Moreover, if in order to become renounced someone tries to destroy his senses, which are the gateways through which he accepts material enjoyment, the affliction he suffers due to separation from his senses will hurt him immensely before he is able to attain true renunciation. 

​	Vaishnavas know that material objects are neither to be enjoyed nor rejected. Rather, they are to be used to give the Lord pleasure. That is, they are ingredidents for His service. Remaining detached from material enjoyment and accepting only what is required to keep the body and soul together, devotees always act as the Lord's menial servants. Karma and gyan are not the soul's constitutional propensity. The soul's only propensity is devotional service.

​	Liberated souls are fully absorbed in the service of their worshipable Lord in Vaikuntha. If one wishes to become liberated from his own conditioned state, he must not try to engage God in supplying him sense objects for his own pleasure, nor should he reject sense objects simply to be renounced. Rather, we should accept those objects that are favorable for his service and reject only those that are unfavorable.
