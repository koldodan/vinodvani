---
layout: post
title: Is it most offensive to disobey the spiritual master's order?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "To disobey the spiritual master's order is the third offense in chanting the holy name. To disregard the spiritual master means to consider him an ordinary living being, a product of matter, an insignificant person. To neglect his service is also an offense against the holy name. If we commit offenses against our spiritual master, the holy name will not appear in our heart. Without the spiritual master's mercy human beings cannot become liberated from the influence of high birth, opulence, vast knowledge, and fame. Such persons will be unable to attain service at the Lord's lotus feet."
---

To disobey the spiritual master's order is the third offense in chanting the holy name. To disregard the spiritual master means to consider him an ordinary living being, a product of matter, an insignificant person. To neglect his service is also an offense against the holy name. If we commit offenses against our spiritual master, the holy name will not appear in our heart. Without the spiritual master's mercy human beings cannot become liberated from the influence of high birth, opulence, vast knowledge, and fame. Such persons will be unable to attain service at the Lord's lotus feet.

​ The spiritual master is the direct manifestation of the Supreme Personality of Godhead. He is servitor of God, yet he is nondifferent from the worshipable Lord. The spiritual master is simultaneously one and different from Nanda Maharaja's son. Just as we cannot see the sun with the help of either sunrays or an artificial light, we cannot see Krsna on our own. But when by the strength of the spiritual master's mercy the fire for material enjoyment is extinguished is our heart, we will be able to see Krsna face to face.

​ However hard we may try to achieve knowledge about the transcendental Absolute Truth without the spiritual master's mercy, we will find that we are laboring uselessly. It will be as if we were beating husk after the grain had been removed. Our attainment of scriptural knowledge depends on the spiritual master's mercy. To try to attain scriptural knwoledge with the help of academic qualifications is an futile as pouring ghee onto ashes.

​ We should never be faithless when hearing the words of _sasta_ or guru. That is an offense. It is necessary to have complete faith in the words of the soiritual master and the scriptures if we are to understand the Absolute Truth. The fourth offense in chanting is to not have complete faith in the _shastric_ statements.
