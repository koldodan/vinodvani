---
layout: post
title: How do we achieve devotional service?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Attaining Krsna's lotus feet is the living entity's topmost achievement, but devotional service can be attained only in the association of devotees. Only the most fortunate souls can attain Krsna. A living entity becomes fortunate when his desire to wander throughout the universe is extinguished. Then, when by the strength of the guru's mercy his constitutional propensity is revived, he attains the seed of devotional service. There is no difference between Krsna's and the guru's mercy."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---



Attaining Krsna's lotus feet is the living entity's topmost achievement, but devotional service can be attained only in the association of devotees. Only the most fortunate souls can attain Krsna. A living entity becomes fortunate when his desire to wander throughout the universe is extinguished. Then, when by the strength of the guru's mercy his constitutional propensity is revived, he attains the seed of devotional service. There is no difference between Krsna's and the guru's mercy. The word *prasada* means "the Lord's mercy." Sri Chaitanya Mahaprabhu states, "According to their karma, all living entities are wandering throughout the entire universe. Some of them are being elevated to the upper planetary systems, and some are going down into the lower planetary systems. Out of many millions of wandering living entities, one who is very fortunate gets an opportunity to associate with a bonafide spiritual master by the grace of Krsna. By the mercy of both Krsna and the spiritual master such a person receives the seed of the creeper of devotional service." CC - Madhya - 19.151

​	Devotional service is defined as a desire to serve the Lord as His menial servant, only for His pleasure. Serving for our own pleasure is not devotion. When the guru plants the seed of devotion in our heart, we have to sow it in the field of the heart and water it with hearing and chanting. "I am a servant and my duty is to serve": when we become established in this conviction, we are gardeners. If after receiving the *bhakti* seed from guru - the seed that Lord Krsna awarded us out of His causeless mercy in the form of the guru - we fail to engage in Krsna's service but become indifferent to that service, we will find ourselves in trouble.

​	Impediments on the devotional path are removed by the strength of the guru's mercy. Once they are removed we will make quick progress. Therefore, we should hear about the Lord from the spiritual master and the saints and study the litereature under their order. "Hearing" includes studying devotional literature. If we become distracted from our guru's feet for even a moment, it is inevitable that we will become degraded.

​	Hearing and chanting about the Lord is like water. Persons who have taken complete shelter at the spiritual master's lotus feet are gardeners. Our only duty is to always serve the guru with love and devotion and to associate with saintly persons. It is essential to nourish and safeguard the devotional creeper by faithfully engaging in the Lord's service. Otherwise, we will face various difficulties.

