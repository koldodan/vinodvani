---
layout: post
title: Is it improper to associate intimately with women?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

One must avoid sinful activities in regard to women. Renunciants must not associate with women at all. Even householders should not indulge in too much lusty activity. A person who forgets Krsna and enjoys this material world is materially attached or an attached householder. It is irreligious to violate the principles of household life. 

```
Mahāprabhu said, 

asat-sañnga-tyāga,-ei vaișnava-ācāra, 

'strī- sangi-eka asãdhu, krsņābhakta' āra: 
```

“A Vaişņava should always avoid the association of ordinary people. Common people are very much materially attached, especially to women. Vaișņavas should also avoid the company of those who are not devotees of Lord Krsna." (Caitanya-caritāmrta Madhya 22.87)
