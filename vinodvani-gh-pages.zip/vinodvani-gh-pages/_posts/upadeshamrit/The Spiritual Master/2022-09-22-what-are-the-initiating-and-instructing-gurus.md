---
layout: post
title: What are the initiating and instructing gurus? What is the function of the guru who dwells in the heart?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "There are three types of spiritual masters, the initiating guru, the instructing guru, and the *caitya-guru*. The spiritual master is never ordinary. He is godly. It is an offense to separate the spiritual master from Sri Krsna Caitanya by considering him an ordinary, insignificant human being. In the form of the spiritual master, Krsna alone awakens the living entity's spiritual consciousness and thereby helps him attain eternal benefit."
---

​ The initiating spiritual master awards the transcendental knowledge, knowledge of the Absolute Truth, "Krsna alone is my eternal master and I am His eternal servant": this transcendental knowledge or _sambhadh-jyana_ is imparted by the initiating spiritual master.

​ An instructing spiritual master first tells us how to remove the _anarthas_, then teaches us the process of pure devotion. In most cases the initiating spiritual master acts as an instructing spiritual master. A conditioned soul cannot act as an initiating or instrcuting spiritual master. An initiating spiritual master teaches the process of _bhajana_ after our anarthas are destroyed.

​ Sri Hari, who dwells in our hearts as the Supersoul, is the internal spiritual master, _caitya-guru_. _Chaitanya-caritamrita_ states, "Krsna is situated in everyone's heart as the _caitya-guru_, the spiritual master within. When He is kind to some fortunate conditioned soul, He personally gives him lessons so he can progress in devotional service, instructing the person as the Supersoul within and the spiritual master without." CC Madhya 22.47

​ The caitya-guru awards us the qualification to realize the instructions we have heard from the initiating and instructing gurus. He also imparts the strength to follow those orders. Without His mercy, no one understand the intention of either the initiating or instructing spiritual master. Lord Sri Gaurangadeva alone awards transcendental knowledge and pure devotional service throught the initiating spiritual master, protects that pure devotion by sending the instructing spiritual masters (who are nondifferent from Him), and as the internal spiritual master personally awards the strength to follow the guru's orders and teachings.
