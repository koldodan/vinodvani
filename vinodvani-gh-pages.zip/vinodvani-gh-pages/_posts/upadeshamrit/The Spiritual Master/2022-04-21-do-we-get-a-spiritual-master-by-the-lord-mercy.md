---
layout: post
title: Do we get a spiritual master by Lord's mercy?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "If we ever become fortunate enough to receive a bona fide spiritual master, all credit goes to Krsna alone. Through the spiritual master, Lord Krsna awards us the benediction of fearlessness. Only the foutunate receive this opportunity. An appropriate spiritual master comes to an appropriate person."
---

If we ever become fortunate enough to receive a bona fide spiritual master, all credit goes to Krsna alone. Through the spiritual master, Lord Krsna awards us the benediction of fearlessness. Only the foutunate receive this opportunity. An appropriate spiritual master comes to an appropriate person.











