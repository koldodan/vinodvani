---
layout: post
title: Should one serve the devotees and the Supreme Lord personally?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "It is not proper to engage others to worship and cook for the Lord. We can, however, make an exception if we are in some predicament or are ill. If out of laziness we do not feed Krsna but we ourselves eat nice foods, then our respect for the Lord's service will diminish."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

It is not proper to engage others to worship and cook for the Lord. We can, however, make an exception if we are in some predicament or are ill. If out of laziness we do not feed Krsna but we ourselves eat nice foods, then our respect for the Lord's service will diminish.

​	It is not proper to disturb or change the thought flow of devotees who live in the Matha or temple. *Dravyah mulyena suddhati:* "We can purchase food if we are unable, for some reason, to cook. Our paying for it purifies what we purchase." This is applicable to those who are unable to cook. It is certainly a symptom of laziness if those who are able to cook go to market to purchase cooked food for offering. We want only to please Krsna. Otherwise, our lives become godless. If we love God, we will want to cook for Him and distribute His remnants to devotees. If we do so, we will never become averse to serving the devotees.

