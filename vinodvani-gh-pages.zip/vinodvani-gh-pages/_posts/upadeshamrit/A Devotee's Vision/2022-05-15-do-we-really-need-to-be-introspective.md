---
layout: post
title: Do we really need to be introspective?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "If we are eager to know the contents of a letter, we show no patience when looking at the envelop. If we see objects in this material world as ingredients only for the Lord's service, we will no longer have external vision. The Supreme Lord is situated everywhere in this world. He is situated in the hearts of all living entities."
---

We have to give up external vision, the vision of material enjoyment and material forms, and become introspective. Until we become introspective, we will continue to depend on external vision. External vision is illusory.

​	If we are eager to know the contents of a letter, we show no patience when looking at the envelop. If we see objects in this material world as ingredients only for the Lord's service, we will no longer have external vision. The Supreme Lord is situated everywhere in this world. He is situated in the hearts of all living entities.

​	"The Lord is always situated in the temple of my heart just to give me the opportunity to serve him." When this conviction becomes prominent in our minds, then according to the logic, "A learned person sees everyone equally. Therefore, I can perceive my worshipable Lord everywhere," we will find our external, inferior, worldy vision cleared. At that time, I will consider the entire world full of happiness.

















