---
layout: post
title: How should we serve devotees of various qualifications?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "We should engage cent percent in the service of the Mahabhagwata."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

We should engage cent percent in the service of the _mahabhagavata_, 66.6 percent in the service of the _madhyama-bhagwata_, and 33.3 oercent in the service of the _kanishta-bhagwata_.
