---
layout: post
title: Why do our hearts change?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "If we do not always serve Hari with love, our mind will become disturbed. Service to Hari should be constant. If there is the slightest interruption in our service, the illusory energy will take advatage of it and shallow us."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

If we do not always serve Hari with love, our mind will become disturbed. Service to Hari should be constant. If there is the slightest interruption in our service, the illusory energy will take advatage of it and shallow us.
