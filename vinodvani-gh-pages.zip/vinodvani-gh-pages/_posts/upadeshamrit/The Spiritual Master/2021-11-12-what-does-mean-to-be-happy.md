---
layout: post
title: What does it mean to be happy?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "By taking shelter of the spiritual master's lotus feet, we become fearless, free of lamentation, and happy. When we serve him, we gain his association. If we serve the spiritual master with body, mind and speech, we quickly attain his mercy."
---

By taking shelter of the spiritual master's lotus feet, we become fearless, free of lamentation, and happy. When we serve him, we gain his association. If we serve the spiritual master with body, mind and speech, we quickly attain his mercy. When he is pleased, we will find that our inclination to serve him progressively increases. This is the highest form of auspiciousness and the only gain.

