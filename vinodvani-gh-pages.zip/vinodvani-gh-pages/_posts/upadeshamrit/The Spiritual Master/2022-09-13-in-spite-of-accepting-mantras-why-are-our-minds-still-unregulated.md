---
layout: post
title: In spite of accepting mantras, why are our minds still unregulated?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "If our minds remain unchanged after having received mantras, it means we have not actually received the mantras. Giving mantras is more than whispering something or blowing air into someone's ears. Accepting mantras initiation means to accept transcendental knowledge. This transcendental knowledge smashes to pieces the pillars of the nescience we have accumulated since time immemorial, then builds pillars of eternal truth out of transcendental knowledge."
---

If our minds remain unchanged after having received mantras, it means we have not actually received the mantras. Giving mantras is more than whispering something or blowing air into someone's ears. Accepting mantras initiation means to accept transcendental knowledge. This transcendental knowledge smashes to pieces the pillars of the nescience we have accumulated since time immemorial, then builds pillars of eternal truth out of transcendental knowledge. When Lord Krsna gave Brahma transcendental knowledge, he said, "I am the Absolute Truth." Only an empowered personality can reveal the Absolute Truth. This empowered personality is the spiritual master. Many insignificant agents or messengers come into this world, but the most powerful messengers are sent by God. Krsna adapts them to the needs of the receipents and calls them spiritual masters. Such expert personalities reveal the Absolute Truth. Only such spiritual masters can destroy our mental speculation and bring about a radical change in our spiritual propensity.

​ The Knowledge we receive from the spiritual master is not mundane but transcendental, spiritual. This transcendental knowledge is Krsna. Krsna is eternal and full of knowledge and bliss. Mantra is fully cognizant. Mantra can definitely regulate our mind. It can deliver the mind from both vice and virtue and award us the qualification to cultivate real spiritual life.
