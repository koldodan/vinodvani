---
layout: post
title: How long does the living entity remain conditioned?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Until devotional service fully blossoms in the living entities, they cannot understand that they are the Supreme Lord's servants, Thus, they remain conditioned. Unless one develops transcendental pride, how can he give up material pride?."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Until devotional service fully blossoms in the living entities, they cannot understand that they are the Supreme Lord's servants, Thus, they remain conditioned. Unless one develops transcendental pride, how can he give up material pride?
