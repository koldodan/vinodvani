---
layout: post
title: What is devotional service or the worship of the Lord?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Whatever is done for Krsna's pleasure is devotional service. Rendering service to the Lord is called devotional service. Dasya-rasa, sakhya-rasa, vatsalya-rasa, and madhurya-rasa are each progressively superior."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Whatever is done for Krsna's pleasure is devotional service. Rendering service to the Lord is called devotional service. Dasya-rasa, sakhya-rasa, vatsalya-rasa, and madhurya-rasa are each progressively superior. Favorable cultivation of Krsna consciousness without any tinge of _anyabhilasa_, karma, jyana, yoga, tapa, or vrata is called _bhajan_, worship of the Lord. Nondevotional processes such as _hatha-yoga_, _raja-yoga, karma-yoga, jyana-yoga_ and _vrata-tapasya-yoga_ cannnot be called _bhajan_. It is not possible to purify the heart completely by practicing karma, jyana, yoga, tapa, or vrata. Only devotional service or hearing _hari-katha_ can purify the heart completely. Even the restless mind becomes purified and pacified simply by serving the Supreme Lord.
