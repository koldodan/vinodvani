---
layout: post
title: Is it important to take shelter at the feet of vaishnvas?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "If we do not take shelter of a devotee's lotus feet, we cannot take shelter of Krsna's lotus feet. Without the association and shelter of the Lord's devotees, we can never obtain the Lord's service. We are all fallen souls and are therefore unable to benefit ourselves. Since we are fallen, we cannot be delivered until we take shelter of the lotus feet of the deliverer of fallen souls. There is no other way to achieve auspiciousness than to associate with devotees."
---

If we do not take shelter of a devotee's lotus feet, we cannot take shelter of Krsna's lotus feet. Without the association and shelter of the Lord's devotees, we can never obtain the Lord's service. We are all fallen souls and are therefore unable to benefit ourselves. Since we are fallen, we cannot be delivered until we take shelter of the lotus feet of the deliverer of fallen souls. There is no other way to achieve auspiciousness than to associate with devotees.
