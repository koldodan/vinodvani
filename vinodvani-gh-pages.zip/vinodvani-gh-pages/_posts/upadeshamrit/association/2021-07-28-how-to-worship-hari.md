---
layout: post
title: How do we worship Hari constantly?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

By always remaining in the association of the livng source - those who are constantly engaged in worshipping Hari - we will, by the mercy of those great souls, automatically receive the good fortune to engage constantly in Lord Hari's service. Therefore, the *shastras* state, *nijabhista krsna-prestha pacheta' lagiya, nirantara seva kare antarmana hana*: "Actually the inhabitants of Vrindavan are very dear to Krishna. If one wants to engage in spontaneous loving service, he must follow the inhabitants of Vrindavan and constantly engage in devotional service within his mind." ~ (Caitanya-Caritamrita Madhya 22.159)

```tex
krsna se tomara, krsna dite paro,
tomara sakati ache
ami to' kańgala, 'krsna' 'krsna' boli',
dhai tava pache pache
```

"Krsna belongs to you. Therefore, you are able to give Him to others. This is certainly within your power. I am indeed wretched and fallen, simply running behind you crying, 'Krsna! Krsna!'"

