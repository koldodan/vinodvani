---
layout: post
title: How do we worship Hari constantly?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

We never desire to associate with those who want to prosper in family life. We should develop a strong desire to serve those who are attached to worshipping Hari and who are situated in family life with Krsna in the centre. It is our duty to give up bad association and take shelter of saints. Those who mistake nondevotees for devotees will certainly find themselves in difficulty.

