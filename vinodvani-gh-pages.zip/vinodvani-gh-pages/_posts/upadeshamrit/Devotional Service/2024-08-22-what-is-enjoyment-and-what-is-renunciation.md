---
layout: post
title: What is enjoyment and what is renunciation?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Enjoyment refers to sense activities, and renunciation refers to remaining aloof from material objects for sense gratification."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Enjoyment refers to sense activities, and renunciation refers to remaining aloof from material objects for sense gratification. When enjoyment is prominent, renunciation is diminished. Neither enjoyment (material variegatedness) nor renunciation (material impersonalism) are necessary in this world. Actual enjoyment means to serve the Supreme Lord; real renunciation means to reject material enjoyment in order to give Krsna pleasure. A devotee's two primary qualities are attachment to Krsna and renunciation of the thirst for material enjoyment. A devotee finds enjoyment in assisting Krsna to satisfy His senses.
