---
layout: post
title: Is every devotee worshipable? Who protects the devotees?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "If any rich or powerful person attacks an *akincana* devotee, Sri Nrsimhadeva will certainly take care of the devotee. Only those among the higher and lower castes in society who have taken shelter of the Lord's devotional service are proper candidates for our spiritual respect and adoration. To consider that a Vaishnava belongs to a particular class is offensive."
---

If any rich or powerful person attacks an *akincana* devotee, Sri Nrsimhadeva will certainly take care of the devotee. Only those among the higher and lower castes in society who have taken shelter of the Lord's devotional service are proper candidates for our spiritual respect and adoration. To consider that a Vaishnava belongs to a particular class is offensive.





















