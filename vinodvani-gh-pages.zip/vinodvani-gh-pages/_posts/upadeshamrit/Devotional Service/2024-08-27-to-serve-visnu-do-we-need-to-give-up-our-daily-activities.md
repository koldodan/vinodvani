---
layout: post
title: To serve Visnu, do we need to give up our daily activities?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Perform all your duties as Vaishnavas. Do not simply engage in day-to-day activities by giving up the principles of Vaishnavism or service to Lord Vishnu. Vaishnavas engage in activities that are favorable for devotional service to Hari."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Perform all your duties as Vaishnavas. Do not simply engage in day-to-day activities by giving up the principles of Vaishnavism or service to Lord Vishnu. Vaishnavas engage in activities that are favorable for devotional service to Hari.
