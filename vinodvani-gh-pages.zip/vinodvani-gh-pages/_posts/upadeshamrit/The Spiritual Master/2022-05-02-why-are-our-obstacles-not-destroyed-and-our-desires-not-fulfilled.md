---
layout: post
title: Why are our obstacles not destroyed and our desires not fulfilled?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "Because we think the spiritual master, who is nondifferent from the Supreme Lord, is a mortal being, our current vision is full of faults. That is why we are unable to sincerely surrender to his lotus feet. We find ourselves in our present pathetic condition because we have transgressed the words of the *Vedas*, the Supreme Lord, and the *Bhagwad-gita* and considered the spiritual master a mortal being, the Vaishnavas as belonging to a particular caste, and the Supreme Lord as made of material elements - stone, wood, or clay."
---

Because we think the spiritual master, who is nondifferent from the Supreme Lord, is a mortal being, our current vision is full of faults. That is why we are unable to sincerely surrender to his lotus feet. We find ourselves in our present pathetic condition because we have transgressed the words of the *Vedas*, the Supreme Lord, and the *Bhagwad-gita* and considered the spiritual master a mortal being, the Vaishnavas as belonging to a particular caste, and the Supreme Lord as made of material elements - stone, wood, or clay.

















