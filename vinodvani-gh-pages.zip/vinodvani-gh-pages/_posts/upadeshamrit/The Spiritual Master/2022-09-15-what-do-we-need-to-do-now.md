---
layout: post
title: What do we need to do now?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'We must hear from a bonafide spiritual master. When we first hear from guru his words appear revolting to us. Some unfortunate people dare to think we can correct our spiritual master by our own experience. But the current of mundane thoughts cannot attack the spiritual master; he is situated millions of miles from such thoughts. He is known as guru because his position does not shift; he is the heaviest personality.'
---

We must hear from a bonafide spiritual master. When we first hear from guru his words appear revolting to us. Some unfortunate people dare to think we can correct our spiritual master by our own experience. But the current of mundane thoughts cannot attack the spiritual master; he is situated millions of miles away from such thoughts. He is known as guru because his position does not shift; he is the heaviest personality.
