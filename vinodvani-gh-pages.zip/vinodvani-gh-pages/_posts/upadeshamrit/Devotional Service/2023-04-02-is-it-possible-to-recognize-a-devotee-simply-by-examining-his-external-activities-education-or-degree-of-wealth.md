---
layout: post
title: Is it possible to recognize a devotee simply by examining his external activities, education, or degree of wealth?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'Materialists are fond of sense gratification, dry renunciants are detached from material enjoyment, recognizing it as the source of misery. Both materialists and dry renunciants are full of material desires and therefore nondevotees. That is why they cannot understand the service attitude and spontaneous renunciation of _bhaktas_. If one tries to recognize a devotee by his external appearance his high birth, opulence, education, beauty, or other material prosperity, or by his lack of these things - he is bound to be deceived.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Materialists are fond of sense gratification, dry renunciants are detached from material enjoyment, recognizing it as the source of misery. Both materialists and dry renunciants are full of material desires and therefore nondevotees. That is why they cannot understand the service attitude and spontaneous renunciation of _bhaktas_. If one tries to recognize a devotee by his external appearance - his high birth, opulence, education, beauty, or other material prosperity, or by his lack of these things - he is bound to be deceived. Even the most intelligent persons are unable to understand a Vaishnav's activities and behaviour. When _karmis_ and _jnanis_, material enjoyers or dry renunciants, look at devotees through their gross, external vision, they do not see the devotee's true identify. A devotee who serves the Lord lacks no opulence, because the Lord Himself possesses all six opulences. Instead of enjoying their opulence, however, devotees offer it to their worshipable Lord and unlike materialists and renunciants; neither enjoy the opulence nor give it up. Therefore, whether one sees a devotee with opulence or with no apparent opulence, one should not disrespect him because that devotee knows perfectly well how to utilize everything in the Supreme Lord's service. A devotee is neither a sense enjoyer nor a renunciant. He is something other than either of these because he gratifies his beloved Lord's senses.

It is only possible to develop this conception by the mercy of a devotee. Therefore, if one engages constantly in Sri Hari's service, constantly chanting His names, giving up false ego, and taking shelter of the Vaisnava guru's lotus feet, then one's improper attempts to measure both the Lord and His devotees, as well as one's material thirst, will diminish and one will certainly attain eternal auspiciousness.
