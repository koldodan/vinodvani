---
layout: post
title: Of What should we be careful?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

Everything in this world belongs to Krsna. If one uses anything for his own enjoyment, he will have to face the consequences. Those who are averse to hearing *krsna-katha* will become materially attached and bound to this world. Therefore, pious persons who desire their eternal benefit should take utmost care to hear *krsna-katha* rom real devotees.

"I serve the Lord so much," "I have already served the Lord," or "I have become a Vaishnav"-- these are sinful thoughts. One must gibe up such madness and humbly beg to attain the Lord's service.

To make a show of serving Krsna without serving the spiritual master and the Vaishnavs is like keeping water in a broken pot. Such pretence is simply pride. One must seek constant association with devotees. I am so weak that I am unable to survive without the associationof devotees. If I do not associate with devotees constantly, I will certainly develop a strong desire to become the master, and various sinful thoughts will disturb me. Material existence is the gateway to hell. Even though it appears pleasing in the beginning, it will disappoint me in the end.
