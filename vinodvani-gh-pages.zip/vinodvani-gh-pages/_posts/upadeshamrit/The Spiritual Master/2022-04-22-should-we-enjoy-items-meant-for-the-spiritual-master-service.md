---
layout: post
title: Should we enjoy the items meant for the spiritual master's service?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "It is an offence to enjoy items offered to the spiritual master. This means that we are treating the spiritual master as if he were an insignificant, ordinary human being."
---

It is an offence to enjoy items offered to the spiritual master. If we do not engage our ears in hearing *hari-katha*, if we engage our eyes only in measuring objects we can see, our nose in smelling fragrances, our tongue in relishing palatable food, and our body in enjoying the sense of touch, then we must be thinking those ingredients meant for the spiritula master's service are objects of our own enjoyment. This means that we are treating the spiritual master as if he were an insignificant, ordinary human being.













