---
layout: post
title: How will our material desires be vanquished?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Srimad Bhagwatam says that Lord Krsna, who is benefactor of devotees, resides in the hearts of devotees who are engaged in hearing His name, form, qualities, etc. He destroys all the lusty desires in their hearts totally. Thus, for one who daily hears or glorifies the most auspicious topics of the Lord, the Lord soon personally appears in his heart."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Srimad Bhagwatam says that Lord Krsna, who is benefactor of devotees, resides in the hearts of devotees who are engaged in hearing His name, form, qualities, etc. He destroys all the lusty desires in their hearts totally. Thus, for one who daily hears or glorifies the most auspicious topics of the Lord, the Lord soon personally appears in his heart.

If we can hear _krsna-katha_ froma bonafide spiritual master and chant the Lord's holy name constantly, then mundane thoughts will be vanquished and remembering Krsna will become a constant affair. The influence of chanting makes remembering Krsna spontaneous. By regularly hearing and chanting about the Lord with a simple heart, all our obstacles are destroyed and we will achieve auspiciousness.
