---
layout: post
title: Will we be cheated if we do not take complete shelter of the spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "we will be cheated in proportion tio our duplicity."
---

We think that now that we have recived mantras from our spiritual master, we are saved. But if we are not prepared to take complete shelter of our spiritual master, we will be cheated in proportion tio our duplicity.





