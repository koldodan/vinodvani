---
layout: post
title: How do we attain devotional service?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "If we wish to attain devotional service, we should first take shelter of a spiritual master. This is the principal limb of the sixty-four limbs of devotional service. Unless we surrender to a spiritual master, we can never become eligible to execute devotional service. Hearing and chanting about the Lord cannot produce good results unless we subordinate ourselves to a guru. If we attempt to practice devotion without submitting to a guru, we will accumulate piety but will not learn to perform pure devotional service."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

If we wish to attain devotional service, we should first take shelter of a spiritual master. This is the principal limb of the sixty-four limbs of devotional service. Unless we surrender to a spiritual master, we can never become eligible to execute devotional service. Hearing and chanting about the Lord cannot produce good results unless we subordinate ourselves to a guru. If we attempt to practice devotion without submitting to a guru, we will accumulate piety but will not learn to perform pure devotional service.

We get a bona fide spiritual master only by good fortune and Krsna's mercy. Those who completely surrender everything to their spiritual master's lotus feet are initiated into _krsna-mantras_ and Lord Krsna's teachings. Partial surrender does not bring a complete result.
