---
layout: post
title: What actions will bring us auspiciousness?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "By serving the spiritual master with great faith we will definitely attain auspiciousness. Human beings work hard in this world of distress simply so they can suffer more and more. This is maya's arrangement for the conditioned souls. Those who are busy trying to attain worldly happiness certainly invite the inauspiciousness. Due to their aversion to the Lord's service, human beings have developed such a mentality. They cannot understand that their distress is caused by their endeavor to achieve personal happiness. The entire fourteen worlds are a place of such inauspiciousness."
---

By serving the spiritual master with great faith we will definitely attain auspiciousness. Human beings work hard in this world of distress simply so they can suffer more and more. This is _maya_'s arrangement for the conditioned souls. Those who are busy trying to attain worldly happiness certainly invite the inauspiciousness. Due to their aversion to the Lord's service, human beings have developed such a mentality. They cannot understand that their distress is caused by their endeavor to achieve personal happiness. The entire fourteen worlds are a place of such inauspiciousness.

​ Unfortunately, we have currently developed the strong misconceptions that we are the doer. How can we free ourselves from such a misconception? We have to take shelter at the spiritual master's lotus feet and engage in the Supreme Lord's service. At present we are busy enjoying this world under the control of our senses. We have come to this world by opposing the Lord's service. We think, "Let everyone gratify my senses. If anyone disturbs my sense gratification, he is bad." The only way to become free of such a miserable condition is to take shelter at the spiritual master's lotus feet.
