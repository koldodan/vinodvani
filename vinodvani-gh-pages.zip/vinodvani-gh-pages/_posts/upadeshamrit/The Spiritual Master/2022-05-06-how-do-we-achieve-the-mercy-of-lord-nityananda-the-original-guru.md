---
layout: post
title: How do we achieve the mercy of Lord Nityananda, the Original Guru?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: I am an export, this is not a transcendentalist's mentality. If we realize that there are no person as fallen, wretched, and unqualified as ourselves in the entire world, then we are eligible to receive the mercy of Nityananda Prabhu, the Original Guru.
---

I am an export; this is not a transcendentalist's mentality. If we realize that there are no person as fallen, wretched, and unqualified as ourselves in the entire world, then we are eligible to receive the mercy of Nityananda Prabhu, the Original Guru.

​	If we live with the spiritual master out of pretense, we may find ourselves in trouble. Similarly, if we live away from the spiritual master, we may also be in trouble. But if we maintain staunch faith and love for our spiritual master and the Vaishnavas, we will certainly be benefited regardless of whether we stay with them or live far away from them.

​	One day a gentleman's son suddenly came to see me. He had passed his entrance examination. He was so detached that he wore a piece of old cloth that only came to above his knee. He came like this every day for few days. At the time I was residing in Sri Mayapur and arranging for property. On seeing my activities he lost faith in me and went elsewhere. He then fell into bad association and became degraded. Therefore, if we want to measure devotees simply by their external appearance and not by understanding their actual intentions, we will certainly bring ruination on ourselves.















