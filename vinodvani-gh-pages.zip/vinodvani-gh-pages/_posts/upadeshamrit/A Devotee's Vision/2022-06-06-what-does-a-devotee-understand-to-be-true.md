---
layout: post
title: What does a devotee understand to be true?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: a-devotee-vision
description: "Actual devotees do not become disturbed in any situation whether it is happy or full of distress, convinient or inconvinient. Rather, they always engage in the Lord's service with body, mind, and speech. Devotees are firmly established in the principle of serving the Lord."
---

Actual devotees do not become disturbed in any situation whether it is happy or full of distress, convinient or inconvinient. Rather, they always engage in the Lord's service with body, mind, and speech. Devotees are firmly established in the principle of serving the Lord. They think, "I am the Lord's servant. Serving him is my life and soul. Apart from service everything is material existence or death." Devotees are by nature inclined to serve the Lord. They cannot remain without service. Only service-inclined devotees are able to serve the object of their service. The object of their service, the servant, and the service are sewn with the same thread.





















