---
layout: post
title:  "Why shudh Naam is not happening?"
date:   2021-03-14 9:49:43 -0500
categories: "upadeshamrit"
author: "Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur"
permalink: /:categories/why-shudh-naam-is-not-happening
tags: association
---



 <img src="../../img/shudh_naam.png" alt="shudh_naam.png" > 
