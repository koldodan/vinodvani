---
layout: post
title: Did you make disciples?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "I have not made anyone my disciples. Those who are considered my disciples by others are actually my spiritual masters. To associate with others means to accept something from them. I do not accept anything from anyone except that which I received from my spiritual master."
---

I have not made anyone my disciples. Those who are considered my disciples by others are actually my spiritual masters. To associate with others means to accept something from them. I do not accept anything from anyone except that which I received from my spiritual master. I do not engage in any activity under anyone's order except the order of my spiritual master. We should not accept anything from anyone for ourselves. If anyone faithfully and gladly gives us something we can use to serve guru and Krsna, we should happily accept it and then use it for the Lord's service. Then we will achieve auspiciousness. If we learn the mystery of engaging everything in the Lord's service without looking at it with an enjoying spirit, we can enter the kingdom of God.















