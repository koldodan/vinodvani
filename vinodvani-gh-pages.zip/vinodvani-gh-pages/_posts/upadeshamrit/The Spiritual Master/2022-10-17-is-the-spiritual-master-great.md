---
layout: post
title: Is the spiritual master great?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "We are smaller than the smaller and the spiritual master is greater than the greatest. The spiritual master serves the Great, and that Great is controlled by his love. Those who worship Krsna in the mood of *madhurya-rasa* accept the spiritual master as nondifferent from the daughter of Vrshabhanu. Those who are candidates for *vatsalya-rasa* accept him as a manifestitation of Nanda and Yashoda. Those who serve on the platform of *sakhya-rasa* know the spiritual master as one of Krsna's friends such as Sudama or Sridhama as well as manifestation of Lord Nityananda, who is the Lord of Krsna's friends. Those who pursue *dasya-rasa* consider the spiritual master a manifestation of Nanda maharaja's servants such as Raktaka and Pakraka."
---

We are smaller than the smaller and the spiritual master is greater than the greatest. The spiritual master serves the Great, and that Great is controlled by his love. Those who worship Krsna in the mood of _madhurya-rasa_ accept the spiritual master as nondifferent from the daughter of Vrshabhanu. Those who are candidates for _vatsalya-rasa_ accept him as a manifestitation of Nanda and Yashoda. Those who serve on the platform of _sakhya-rasa_ know the spiritual master as one of Krsna's friends such as Sudama or Sridhama as well as manifestation of Lord Nityananda, who is the Lord of Krsna's friends. Those who pursue _dasya-rasa_ consider the spiritual master a manifestation of Nanda maharaja's servants such as Raktaka and Pakraka.

​ The spiritual master is the predominated Supreme Lord. No one should misunderstood him to be the original predominanting Supreme Lord or the object of service. There is a difference between how we see the spiritual master when we have _anarthas_ and how we see the spiritual master when we are free of _anarthas_.

​ We have to serve the Lord in the same way our spiritual master serves Him. If we serve the Lord whimsically and independently, we will not be successful. Material existence means the mundane concept of life. Our misconceptions can be removed by the spiritual master's mercy, because the spiritual master sees everything with equal vision. The Lord's devotees know that this world is meant to be used in the Lord's service. When our hearts are free of material desire, we will see every impediment we experience as Krsna's mercy. Our ruination is inevitable if we think that the spiritual master is an imperfect, mortal being like ourselves, or that he is little better than we are. The spiritual master is our life and soul. Without his shelter, we will not be able to understand the spiritual conception of life and our journey will be limited to the platform of direct, indirect, and beyond the direct and indirect.

​ Maya refers to what we can see, smell, touch, and enjoy. We have to become servants of the transcendental Lord. We cannot achieve such service through a hired priest or the representative of a hired priest.
