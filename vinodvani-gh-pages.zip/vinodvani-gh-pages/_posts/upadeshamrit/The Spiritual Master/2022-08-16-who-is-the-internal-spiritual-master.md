---
layout: post
title: Who is the internal spiritual master?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'The localized Paramatma, the individual Godhead situated within the heart of every living entity, who is described in the Vedas beginning with the verse *dva suparna*, is the internal, pure, unalloyed conscience spiritual master, the caitya-guru.'
---

The localized Paramatma, the individual Godhead situated within the heart of every living entity, who is described in the Vedas beginning with the verse _dva suparna_, is the internal, pure, unalloyed "conscience spiritual master," the caitya-guru.
