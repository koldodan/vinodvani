---
layout: post
title: What quality must we possess before we make disciples?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "We don't need to make disciples, we need to become disciples. In other words, we must always engage in the service of guru and Krsna. The Vaishnavas, the devotees of Visnu, see the spiritual master in everything. If we are proud to be Vaishnavas, we cannot serve Lord Vishnu or the Vaishnavas properly."
---

We don't need to make disciples, we need to become disciples. In other words, we must always engage in the service of guru and Krsna. The Vaishnavas, the devotees of Visnu, see the spiritual master in everything. If we are proud to be Vaishnavas, we cannot serve Lord Vishnu or the Vaishnavas properly. 

​	"I don't do anything myself. Rather, I do whatever the Lord makes me do." Persons devoid of this mentality and engaged in the Lord's service can actually benefit other living entities by helping them become inclined towards Krsna. Simply, speaking about humility is useless. One has to be firmly convinced that "I am actually directed by the Lord."













