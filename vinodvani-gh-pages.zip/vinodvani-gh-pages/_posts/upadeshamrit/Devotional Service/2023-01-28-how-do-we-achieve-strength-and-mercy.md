---
layout: post
title: How do we achieve strength and mercy?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Mercy and spiritual strength are invested in the heart when one takes shelter at the lotus feet of guru without deviation. The spiritual master gives strength and mercy. Nourished by devotional service, the spiritual master's gift of mercy and strength gradually destroy one's anarthas."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Mercy and spiritual strength are invested in the heart when one takes shelter at the lotus feet of guru without deviation. The spiritual master gives strength and mercy. Nourished by devotional service, the spiritual master's gift of mercy and strength gradually destroy one's anarthas. If, however, one renounces devotional service or becomes indifferent to it, the anarthas will again become prominent and gradually dim the effect of the Lord's mercy and strength. When a seed fructifies, a small plant grows from it. By gradually watering this plant, it will eventually grow into a tall tree. It is necessary, however, to protect the plant from external attack until it reaches maturity. In the same way, one must gradually nourish the mercy and strength the guru bestows and enhance it by practicing *bhajana*.

