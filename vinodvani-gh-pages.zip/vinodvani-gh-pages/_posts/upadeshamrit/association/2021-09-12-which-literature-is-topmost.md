---
layout: post
title: Which literature is topmost?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: association
---

There is no literature in the world as valuable as Śrīmad- Bhāgavatam. But it is difficult to study Srīmad-Bhāgavatam without the association of saintly persons and the spiritual master.
