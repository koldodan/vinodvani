---
layout: post
title: Isn't the dust from the feet of guru and Vaishnavas worshipable?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: "If the spiritual master and the saintly persons mercifully allow us to take dust from their lotus feet, we should respectfully accept it. However there is a possibility of inviting inauspiciousness if we forcibly or by request try to take dust from their lotus feet. One day, when a person named Vrndavanacandra Lashkar touched my spiritual master's lotus feet, my spiritual master became upset"
---

If the spiritual master and the saintly persons mercifully allow us to take dust from their lotus feet, we should respectfully accept it. However there is a possibility of inviting inauspiciousness if we forcibly or by request try to take dust from their lotus feet. One day, when a person named Vrndavanacandra Lashkar touched my spiritual master's lotus feet, my spiritual master became upset and said, "How dare you touch my feet? You will go to hell." When laskhar told me about it I explained, "Even persons like Brahma have difficulty achieving the spiritual master's lotus feet. Attaining the spiritual master's feet is rare. Therefore, what right or qualification do we have to touch the guru feet? We cannot approach the spiritual master unless we are eligible. We cannot approach the spiritual master with our sinful mentalities and offensive hearts."

​ One day, out of his causeless mercy, my spiritual master personally took the dust from his own feet and smeared it on my head. Such was his mercy!
