---
layout: post
title: Who should live in the Matha?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Our Matha is not meant for wrestlers nor do aristocrats need to live in the Matha. Only Lord Hari devotees should live in Matha. If we remove the people in the Matha who are fond of eating and enjoying initimate association with women, the Matha expenditures and problems will diminish. We have to send home those proud and independent people who do not follow the Matha rules and regulations, and who neither follow the spiritual master orders nor display humility."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Our Matha is not meant for wrestlers; nor do aristocrats need to live in the Matha. Only Lord Hari's devotees should live in Matha. If we remove the people in the Matha who are fond of eating and enjoying initimate association with women, the Matha's expenditures and problems will diminish. We have to send home those proud and independent people who do not follow the Matha's rules and regulations, and who neither follow the spiritual master's orders nor display humility. If as a result we have less manpower, we are content. We should not allow those who are not interested in worshiping Hari but who aspire for profit, adoration, distinction, women, and wealth to live in the Matha. Such people are opposed to the Matha in their hearts. They think, "I have been living in the Matha for a long time. I have worked hard for the Matha, and therefore can now eat nice foods, dress opulently, demand respect from others, and be given a share in Matha administration." We should never encourage such ideas, because they are opposed to devotional service. Such mentalities develop when living entities indulge in doubt, blasphemy, and idle talk.

​	We should not be proud and think, "I am expert, intelligent, a good speaker, and a good singer." These thoughts are averse to devotional service. We need to feel ourselves lower than the straw in the street. If anyone attacks or criticizes us, we should tolerate it and simply chant Hari's Holy name. We should think that today the Lord has mercifully awarded us the opportunity to become humbler than a blade of grass. When someone blasphemes us, we should know that the Lord is awarding us a benediction through those whose trouble is inevitable.
