---
layout: post
title: Whom should the Matha avoid?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "The Matha does not and cannot have relationship with anyone who takes shelter of the Math but is under the control of duplicity (Someone with the desire to misuse transcendental knowledge). Just as we need a boat and a boatman to cross the river, we need a spiritual master to cross the material ocean."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

The Matha does not and cannot have relationship with anyone who takes shelter of the Math but is under the control of duplicity (Someone with the desire to misuse transcendental knowledge). Just as we need a boat and a boatman to cross the river, we need a spiritual master to cross the material ocean. With such a mentality, these people accepted me as their spiritual master. They have never actually seen me, nor did I ever associate with them. I do not wish to associate with such people ever in my life. Although these people may not have been cheating from the beginning, they commited offenses at the feet of guru and the Vaishnavas and have fallen from the path of devotional service to Hari, again taking to material life.

​	As soon as we try to argue with our guru, as soon as we attempt to measure the guru with our mundane knowledge, and as soon as we imitate the guru rather than follow him, we invite inauspiciousness and ruination upon ourselves. We attain benefit only when we give up such a mentality. Mundane wealth, education, expertise, and knowledge are not good assets for devotees because they influence one to disregard guru and Vaishnavas. As a result, one may become bereft of the guru and Krsna's service.
