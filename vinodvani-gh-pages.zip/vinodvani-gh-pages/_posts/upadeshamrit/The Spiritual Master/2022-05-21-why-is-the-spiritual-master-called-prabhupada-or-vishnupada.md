---
layout: post
title: Why is the spiritual master called Prabhupada or Vishnupada?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'Since the spiritual master is conversant with the science of Krsna and is the personification of the highest service to the Lord, his disciple considers him just like Krsna Caitanya or Hari Himself. Therefore, the disciple addresses him as Vishnupada or Prabhupada.'
---

Since the spiritual master is conversant with the science of Krsna and is the personification of the highest service to the Lord, his disciple considers him just like Krsna Caitanya or Hari Himself. Therefore, the disciple addresses him as Vishnupada or Prabhupada.
