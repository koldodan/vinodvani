---
layout: post
title: What is the highest welfare activity?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: "Let everyone be devoted to Krsna. This is the highest benediction for the world's people. The highest form of welfare is to engage people's minds at Krsna's lotus feet. The topmost charity or altruism is to distribute Krsna's devotional service to everyone. The devotees are always anxious to help others in this way."
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Let everyone be devoted to Krsna. This is the highest benediction for the world's people. The highest form of welfare is to engage people's minds at Krsna's lotus feet. The topmost charity or altruism is to distribute Krsna's devotional service to everyone. The devotees are always anxious to help others in this way.

​	To know God is supreme knowledge. The *sastra* says that knowledge means to know the Supreme Lord. Sri Chaitanya Mahaprabhu inquired: "Of all types of education, which is the most important?" Ramananda Raya replied: "No education is important other than the transcendental devotional service of Krsna." CC-M-8.245

​	The godless education that is being disseminated does not in any way benefit the gerneral populace. Rather, the people have been harmed by it and will continue to be harmed. Humankind can be benefited instead simply by distributing Sri Chaitanyadeva's mercy.

