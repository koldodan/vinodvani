---
layout: post
title: What is the meaning of initiation?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'In the beginning, we have to know our relationship with the Supreme Lord. Initiation is another name for the kind of knowledge we gain when we come to understand our relationship with the Supreme Lord. Merely receiving instructions regarding how to chant mantras is not initiation. Initiation is that act by which we attain transcendental knowledge. The living entities cannot benefit themselves even after studying hundreds of pieces of literature or by making show of whimsical worship.'
---

In the beginning, we have to know our relationship with the Supreme Lord. Initiation is another name for the kind of knowledge we gain when we come to understand our relationship with the Supreme Lord. Merely receiving instructions regarding how to chant mantras is not initiation. Initiation is that act by which we attain transcendental knowledge. The living entities cannot benefit themselves even after studying hundreds of pieces of literature or by making show of whimsical worship. Mercifully, the spiritual master imparts transcendental knowledge unto his sincere disciples who are inclined to serve the Lord. Only a devotee who completely follows his spiritual master's orders by renouncing his independence is eligible to receive the spiritual master's mercy and become successful in attaining actual transcendental knowledge.
