---
layout: post
title: What is service?
categories: upadeshamrit
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'That which gives pleasure to Lord Hari is service and that which gives pleasure to ourselves is enjoyment. Duplicitous people may worsship the Deity with sixteen ingredients in order to get sons and gradsons, but this cannot be called service because the purpose behind their worship is to get something from the Lord. There is so much cheating going on in the name of Deity worship and chanting of the holy name.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

That which gives pleasure to Lord Hari is service and that which gives pleasure to ourselves is enjoyment. Duplicitous people may worsship the Deity with sixteen ingredients in order to get sons and gradsons, but this cannot be called service because the purpose behind their worship is to get something from the Lord. There is so much cheating going on in the name of Deity worship and chanting of the holy name.

Actually, service the Lord and making a show of serving the Lord are two separate things. We should be extremely careful to make sure that we are rendering service to the Deity. Not just anyone can become a servant of the Lord's Deity. Simply paying twenty rupees does not allow us to hear the Lord's holy names or a discourse on _hari-katha_. Such purchased recitations attract people because of the melodious singing and flowery langauge, but they have nothing to do with devotional service or Vaishnava _dharma_. Instead, these recitations are _karma-kanda_, material enjoyment. A _brahmana_ priest who has been hired for ten rupees cannot serve the Lord. Until we are firmly convinced that service to Lord Vishnu and the Vaishnavas is the highest attainment, we cannot benefit.
