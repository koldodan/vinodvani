---
layout: post
title: What kind of Vaishnava has no possessions?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: devotional-service
description: 'the material world simply contains ingridents for the service of Hari, guru, and the vaishnavas. They do not see this mateial world in the spirit of personal enjoyment, nor do they become indifferent to it. Rather, they engage everything in this world in the Supreme Lords service. Unless we worship Lord Hari, we have no right to take even a blade of grass from this world.'
image:
  path: /img/Prabhupad.png
  height: 100
  width: 100
  alt: Prabhupad
---

Those who want nothing from this world are actually _akincana_, devoid of possessions. Such Vaishnavas have understood that there is nothing in this world that can give them eternal hapiness. The material world is a prison house for conditioned souls. Because we have been averse to Krsna, we have been impriosned here and have suffered the material miseries.

Although Prahalada Maharaja was an emperor, he had no possessions. Sudhama Brahmana was extermely improverished, and he too was _akincana_. Both devotees were free of material desire.

The _akincana_ devotees know well that the material world simply contains ingridents for the service of Hari, guru, and the vaishnavas. They do not see this mateial world in the spirit of personal enjoyment, nor do they become indifferent to it. Rather, they engage everything in this world in the Supreme Lord's service. Unless we worship Lord Hari, we have no right to take even a blade of grass from this world. _Akincana_ devotees realize this fact.

The devotees are convinced that by rendering devotional service to Krsna they can attain happiness and auspiciousness. By constantly and offenselessly chanting Krsna's holy name, they realize the essential characteristics of Vaishnavas, devotional service, and the Supreme Lord.

We have to hear _Krsna-katha_ from the spiritual master and the Vaishnavas and then preach it to others. This is how we cultivate Krsna consciousness. If we are not cultivating Krsna consciousness, we will certainly cultivate attitudes unrealtaed to Krsna.
