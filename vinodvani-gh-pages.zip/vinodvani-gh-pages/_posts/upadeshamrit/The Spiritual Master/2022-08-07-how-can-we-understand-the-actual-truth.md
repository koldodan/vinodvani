---
layout: post
title: How can we understand the actual truth?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
description: 'The faith, devotion, and tastes of godless people are always opposed to devotion. With such faith, devotion, and tastes, human beings will never be able to understand actual truth. When the Absolute Truth personally appears by His causeless mercy, He reveals Himself to the surrendered souls. In the form of the SuperSoul, the Lord reveals to sincere souls to whom they should surrender. Actual truth comes down to us through the pure and perfect process of disciplic succession.'
---

The faith, devotion, and tastes of godless people are always opposed to devotion. With such faith, devotion, and tastes, human beings will never be able to understand actual truth. When the Absolute Truth personally appears by His causeless mercy, He reveals Himself to the surrendered souls. In the form of the SuperSoul, the Lord reveals to sincere souls to whom they should surrender. Actual truth comes down to us through the pure and perfect process of disciplic succession.
