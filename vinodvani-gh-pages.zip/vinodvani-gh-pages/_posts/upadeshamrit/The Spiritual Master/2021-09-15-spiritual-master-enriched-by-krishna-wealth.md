---
layout: post
title: Is the spiritual master enriched by Krsna's wealth?
categories: [upadeshamrit]
author: Prabhupada Srila Bhakti Siddhanta Sarasvati Thakur
tags: the_spiritual_master
---

The Spiritual master is the proprietor of the Supreme Lord. Sri Krsna is the spiritual master's property or wealth. That is why only the spiritual master is able to give Krsna. Simply by the spiritual master's mercy we can attain the mercy and *darshan* of Krsna.

